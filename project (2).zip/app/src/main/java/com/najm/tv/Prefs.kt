package com.najm.tv

import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.Color

object Palette {
    val accents = listOf(Color(0xFFE50914), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFFB300), Color(0xFF8E24AA))
    val bgs = listOf(Color(0xFF141414), Color(0xFF000000), Color(0xFF0B1426))
}

class AppPrefs(private val sp: SharedPreferences) {
    var mode by mutableStateOf(sp.getString("mode", "") ?: "")
    var server by mutableStateOf(sp.getString("server", "") ?: "")
    var user by mutableStateOf(sp.getString("user", "") ?: "")
    var pass by mutableStateOf(sp.getString("pass", "") ?: "")
    var m3u by mutableStateOf(sp.getString("m3u", "") ?: "")
    var accent by mutableIntStateOf(sp.getInt("accent", 0))
    var bg by mutableIntStateOf(sp.getInt("bg", 0))
    var scale by mutableFloatStateOf(sp.getFloat("scale", 1f))
    var banner by mutableStateOf(sp.getBoolean("banner", true))
    var liveExt by mutableStateOf(sp.getString("liveExt", "m3u8") ?: "m3u8")
    val favorites = mutableStateListOf<String>().apply { addAll(sp.getStringSet("fav", emptySet()) ?: emptySet()) }
    val recent = mutableStateListOf<String>().apply {
        addAll((sp.getString("recent", "") ?: "").split("\n").filter { it.isNotEmpty() })
    }

    fun save() {
        sp.edit()
            .putString("mode", mode).putString("server", server).putString("user", user)
            .putString("pass", pass).putString("m3u", m3u)
            .putInt("accent", accent).putInt("bg", bg).putFloat("scale", scale)
            .putBoolean("banner", banner).putString("liveExt", liveExt)
            .putStringSet("fav", favorites.toSet())
            .putString("recent", recent.joinToString("\n"))
            .apply()
    }

    fun toggleFav(k: String) {
        if (!favorites.remove(k)) favorites.add(k)
        save()
    }

    fun addRecent(k: String) {
        recent.remove(k)
        recent.add(0, k)
        while (recent.size > 20) recent.removeAt(recent.lastIndex)
        save()
    }
}
