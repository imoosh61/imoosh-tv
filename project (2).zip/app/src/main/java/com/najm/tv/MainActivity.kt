package com.najm.tv

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
val LocalBg = compositionLocalOf { Color(0xFF141414) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = AppPrefs(getSharedPreferences("najm", Context.MODE_PRIVATE))
        Repo.prefs = prefs
        setContent { App(prefs) }
    }
}

// ---------- عناصر مساعدة ----------

@Composable
fun Txt(text: String, size: Int = 16, bold: Boolean = false, color: Color = Color.White, maxLines: Int = Int.MAX_VALUE) {
    Text(
        text, color = color, fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else null,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun Center(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center, content = content)
}

@Composable
fun FocusButton(text: String, selected: Boolean = false, filled: Boolean = false, onClick: () -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val bg = when {
        f -> accent
        filled -> accent.copy(alpha = 0.55f)
        selected -> Color.White.copy(alpha = 0.28f)
        else -> Color.White.copy(alpha = 0.08f)
    }
    Box(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Txt(text, 16, selected || f) }
}

@Composable
fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(color)
            .border(3.dp, if (f) Color.White else if (selected) Color.Gray else Color.Transparent, CircleShape)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
    )
}

@Composable
fun Card(item: Item, onFocus: () -> Unit = {}, onClick: () -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (f) 1.08f else 1f, label = "scale")
    val live = item.type == Type.LIVE
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .size(if (live) 190.dp else 130.dp, if (live) 110.dp else 190.dp)
            .graphicsLayer(scaleX = sc, scaleY = sc)
            .clip(shape)
            .background(Color(0xFF2A2A2A))
            .then(if (f) Modifier.border(3.dp, accent, shape) else Modifier)
            .onFocusChanged { f = it.isFocused; if (it.isFocused) onFocus() }
            .clickable(onClick = onClick)
    ) {
        if (item.poster != null) {
            AsyncImage(
                model = item.poster, contentDescription = null,
                contentScale = if (live) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier.fillMaxSize().padding(if (live) 14.dp else 0.dp)
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                .padding(6.dp)
        ) { Txt(item.title, 12, maxLines = 2) }
    }
}

fun play(ctx: Context, p: AppPrefs, key: String?, url: String, title: String) {
    if (key != null) p.addRecent(key)
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("url", url).putExtra("title", title))
}

// ---------- التطبيق ----------

@Composable
fun App(p: AppPrefs) {
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalDensity provides Density(d.density, p.scale),
        LocalAccent provides Palette.accents[p.accent],
        LocalBg provides Palette.bgs[p.bg]
    ) {
        Box(Modifier.fillMaxSize().background(Palette.bgs[p.bg])) {
            var loggedIn by remember { mutableStateOf(p.mode.isNotEmpty()) }
            if (!loggedIn) {
                LoginScreen(p) { loggedIn = true }
            } else {
                Loader(p, onLogout = { p.mode = ""; p.save(); loggedIn = false })
            }
        }
    }
}

@Composable
fun Loader(p: AppPrefs, onLogout: () -> Unit) {
    var state by remember { mutableStateOf("loading") }
    var msg by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        state = "loading"
        try {
            Repo.load(p)
            state = "ok"
        } catch (e: Exception) {
            msg = e.message ?: e.toString()
            state = "error"
        }
    }
    when (state) {
        "loading" -> Center { Txt("جاري تحميل المحتوى...\nقد يستغرق ذلك دقيقة في أول مرة", 20) }
        "error" -> Center {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Txt("تعذّر التحميل: $msg", 18, color = Color(0xFFFF6B6B))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FocusButton("إعادة المحاولة", filled = true) { reload++ }
                    FocusButton("تغيير الحساب") { onLogout() }
                }
            }
        }
        else -> Shell(p, onReload = { reload++ }, onLogout = onLogout)
    }
}

@Composable
fun LoginScreen(p: AppPrefs, onDone: () -> Unit) {
    var xt by remember { mutableStateOf(p.mode != "m3u") }
    var server by remember { mutableStateOf(p.server) }
    var user by remember { mutableStateOf(p.user) }
    var pass by remember { mutableStateOf(p.pass) }
    var m3u by remember { mutableStateOf(p.m3u) }
    var err by remember { mutableStateOf("") }
    Center {
        Column(
            Modifier.width(520.dp).verticalScroll(rememberScrollState()).padding(vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Txt("نجم TV", 36, true, LocalAccent.current)
            Txt("سجّل دخولك باشتراكك", 16, color = Color.LightGray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FocusButton("Xtream Codes", selected = xt) { xt = true }
                FocusButton("رابط M3U", selected = !xt) { xt = false }
            }
            if (xt) {
                Field("رابط السيرفر (مثال: http://host:8080)", server) { server = it }
                Field("اسم المستخدم", user) { user = it }
                Field("كلمة المرور", pass, true) { pass = it }
            } else {
                Field("رابط قائمة M3U", m3u) { m3u = it }
            }
            if (err.isNotEmpty()) Txt(err, 14, color = Color(0xFFFF6B6B))
            FocusButton("دخول", filled = true) {
                val ok = if (xt) server.isNotBlank() && user.isNotBlank() && pass.isNotBlank() else m3u.isNotBlank()
                if (!ok) {
                    err = "عبّئ كل الحقول"
                } else {
                    p.mode = if (xt) "xtream" else "m3u"
                    p.server = server; p.user = user; p.pass = pass; p.m3u = m3u
                    p.save()
                    onDone()
                }
            }
        }
    }
}

@Composable
fun Field(label: String, value: String, password: Boolean = false, onChange: (String) -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    Column(Modifier.fillMaxWidth()) {
        Txt(label, 13, color = Color.LightGray)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp, textDirection = TextDirection.Ltr),
            cursorBrush = SolidColor(Color.White),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Color(0xFF2A2A2A))
                .border(2.dp, if (f) accent else Color.Transparent, shape)
                .onFocusChanged { f = it.isFocused }
                .padding(12.dp)
        )
    }
}

// ---------- الهيكل الرئيسي ----------

@Composable
fun Shell(p: AppPrefs, onReload: () -> Unit, onLogout: () -> Unit) {
    val tabs = listOf("الرئيسية", "الأفلام", "المسلسلات", "البث المباشر", "بحث", "التنزيلات", "الإعدادات")
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Item?>(null) }
    BackHandler(detail != null) { detail = null }
    val d = detail
    if (d != null) {
        Detail(p, d)
    } else {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Txt("نجم TV", 24, true, LocalAccent.current)
                Spacer(Modifier.width(20.dp))
                tabs.forEachIndexed { i, t -> FocusButton(t, selected = i == tab) { tab = i } }
            }
            when (tab) {
                0 -> Home(p) { detail = it }
                1 -> Browse(p, Repo.movies) { detail = it }
                2 -> Browse(p, Repo.series) { detail = it }
                3 -> Browse(p, Repo.live) { detail = it }
                4 -> SearchScreen { detail = it }
                5 -> DownloadsScreen(p)
                else -> SettingsScreen(p, onReload, onLogout)
            }
        }
    }
}

@Composable
fun Hero(item: Item?) {
    val bg = LocalBg.current
    Box(Modifier.fillMaxWidth().height(190.dp)) {
        if (item?.poster != null) {
            AsyncImage(
                model = item.poster, contentDescription = null, contentScale = ContentScale.Crop,
                alpha = 0.3f, modifier = Modifier.fillMaxSize()
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, bg))))
        if (item != null) {
            Column(Modifier.align(Alignment.BottomStart).padding(horizontal = 40.dp, vertical = 10.dp)) {
                Txt(item.title, 30, true, maxLines = 1)
                val meta = listOfNotNull(
                    item.category,
                    item.rating.takeIf { it.isNotBlank() && it != "0" }?.let { "★ $it" }
                ).joinToString("  •  ")
                Txt(meta, 14, color = Color.LightGray, maxLines = 1)
                if (item.plot.isNotBlank()) Txt(item.plot, 13, color = Color.LightGray, maxLines = 2)
            }
        }
    }
}

@Composable
fun RowSection(title: String, list: List<Item>, onFocus: (Item) -> Unit = {}, open: (Item) -> Unit) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Box(Modifier.padding(horizontal = 40.dp, vertical = 4.dp)) { Txt(title, 18, true) }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 40.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(list.take(100)) { it0 -> Card(it0, onFocus = { onFocus(it0) }) { open(it0) } }
        }
    }
}

@Composable
fun Home(p: AppPrefs, open: (Item) -> Unit) {
    var hero by remember {
        mutableStateOf(Repo.movies.maxByOrNull { it.added } ?: Repo.series.firstOrNull() ?: Repo.live.firstOrNull())
    }
    val newM = remember { Repo.movies.sortedByDescending { it.added }.take(30) }
    val newS = remember { Repo.series.sortedByDescending { it.added }.take(30) }
    val cats = remember {
        Repo.movies.groupBy { it.category }.entries.take(6).map { "أفلام - ${it.key}" to it.value.take(40) } +
            Repo.series.groupBy { it.category }.entries.take(4).map { "مسلسلات - ${it.key}" to it.value.take(40) }
    }
    val recent = p.recent.mapNotNull { Repo.byKey[it] }
    val favs = p.favorites.mapNotNull { Repo.byKey[it] }
    val rows = listOf(
        "تابع المشاهدة" to recent,
        "المفضلة" to favs,
        "أفلام مضافة حديثاً" to newM,
        "مسلسلات مضافة حديثاً" to newS,
        "قنوات مباشرة" to Repo.live.take(30)
    ) + cats
    Column(Modifier.fillMaxSize()) {
        if (p.banner) Hero(hero)
        LazyColumn(Modifier.fillMaxSize()) {
            rows.filter { it.second.isNotEmpty() }.forEach { (title, list) ->
                item { RowSection(title, list, onFocus = { hero = it }, open = open) }
            }
        }
    }
}

@Composable
fun Browse(p: AppPrefs, items: List<Item>, open: (Item) -> Unit) {
    if (items.isEmpty()) {
        Center { Txt("لا يوجد محتوى في هذا القسم", 18, color = Color.Gray) }
        return
    }
    val groups = remember(items) { items.groupBy { it.category }.toList() }
    val newest = remember(items) { items.sortedByDescending { it.added }.take(30) }
    val favs = remember(items, p.favorites.size) { items.filter { it.key in p.favorites }.take(100) }
    LazyColumn(Modifier.fillMaxSize()) {
        if (favs.isNotEmpty()) item { RowSection("المفضلة", favs, open = open) }
        if (items.first().type != Type.LIVE) item { RowSection("المضافة حديثاً", newest, open = open) }
        groups.forEach { (cat, list) -> item { RowSection(cat, list, open = open) } }
    }
}

@Composable
fun SearchScreen(open: (Item) -> Unit) {
    var q by remember { mutableStateOf("") }
    val res = remember(q) {
        if (q.trim().length < 2) emptyList() else Repo.all.filter { it.title.contains(q.trim(), true) }.take(60)
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp)) {
        Field("ابحث عن فيلم أو مسلسل أو قناة", q) { q = it }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(200.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(res) { it0 -> Card(it0) { open(it0) } }
        }
    }
}

// ---------- التفاصيل ----------

@Composable
fun Detail(p: AppPrefs, item: Item) {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<SeriesInfo?>(null) }
    LaunchedEffect(item.key) {
        if (item.type == Type.SERIES) {
            info = try {
                Repo.seriesInfo(item)
            } catch (e: Exception) {
                SeriesInfo("تعذّر تحميل الحلقات", emptyList())
            }
        }
    }
    val fav = item.key in p.favorites
    val plot = if (item.type == Type.SERIES) (info?.plot ?: item.plot) else item.plot
    val meta = listOfNotNull(
        item.category,
        item.rating.takeIf { it.isNotBlank() && it != "0" }?.let { "★ $it" }
    ).joinToString("  •  ")
    Row(Modifier.fillMaxSize().padding(40.dp)) {
        Box(Modifier.width(220.dp).height(320.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2A2A2A))) {
            if (item.poster != null) {
                AsyncImage(
                    model = item.poster, contentDescription = null,
                    contentScale = if (item.type == Type.LIVE) ContentScale.Fit else ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(32.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Txt(item.title, 30, true, maxLines = 2)
            Txt(meta, 15, color = Color.LightGray)
            if (plot.isNotBlank()) Txt(plot, 14, color = Color.LightGray, maxLines = 4)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (item.type != Type.SERIES) {
                    FocusButton("▶ تشغيل", filled = true) { play(ctx, p, item.key, Repo.playUrl(item), item.title) }
                }
                if (item.type == Type.MOVIE) {
                    FocusButton("⬇ تنزيل") { Downloads.enqueue(ctx, Repo.playUrl(item), item.title, item.ext) }
                }
                FocusButton(if (fav) "★ إزالة من المفضلة" else "☆ إضافة للمفضلة") { p.toggleFav(item.key) }
            }
            if (item.type == Type.SERIES) {
                val eps = info?.episodes
                if (eps == null) {
                    Txt("جاري تحميل الحلقات...", 15, color = Color.Gray)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(eps) { e ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FocusButton("▶ م${e.season} ح${e.num}  ${e.title}") {
                                    play(ctx, p, item.key, Repo.episodeUrl(e), "${item.title} - ${e.title}")
                                }
                                FocusButton("⬇") {
                                    Downloads.enqueue(ctx, Repo.episodeUrl(e), "${item.title} م${e.season} ح${e.num}", e.ext)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- التنزيلات ----------

@Composable
fun DownloadsScreen(p: AppPrefs) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(emptyList<Dl>()) }
    LaunchedEffect(Unit) {
        while (true) {
            list = withContext(Dispatchers.IO) { Downloads.list(ctx) }
            delay(2000)
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Txt("التنزيلات", 24, true)
        if (list.isEmpty()) Txt("لا توجد تنزيلات بعد. افتح أي فيلم أو حلقة واضغط تنزيل.", 15, color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { d ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f)) {
                        Txt(d.title, 16, true, maxLines = 1)
                        Txt(d.statusText(), 13, color = Color.LightGray)
                    }
                    if (d.status == DownloadManager.STATUS_SUCCESSFUL && d.uri != null) {
                        FocusButton("▶ تشغيل", filled = true) { play(ctx, p, null, d.uri, d.title) }
                    }
                    FocusButton("🗑 حذف") {
                        Downloads.remove(ctx, d.id)
                        list = list.filter { it.id != d.id }
                    }
                }
            }
        }
    }
}

// ---------- الإعدادات ----------

@Composable
fun SettingsScreen(p: AppPrefs, onReload: () -> Unit, onLogout: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 40.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Txt("الإعدادات", 26, true)
        Txt("لون التطبيق", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Palette.accents.forEachIndexed { i, c -> ColorDot(c, p.accent == i) { p.accent = i; p.save() } }
        }
        Txt("لون الخلفية", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("رمادي داكن", "أسود", "أزرق ليلي").forEachIndexed { i, n ->
                FocusButton(n, selected = p.bg == i) { p.bg = i; p.save() }
            }
        }
        Txt("حجم الخط", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("صغير" to 0.85f, "عادي" to 1f, "كبير" to 1.2f).forEach { (n, s) ->
                FocusButton(n, selected = p.scale == s) { p.scale = s; p.save() }
            }
        }
        Txt("البانر الكبير في الرئيسية", 16, color = Color.LightGray)
        FocusButton(if (p.banner) "مفعّل" else "معطّل") { p.banner = !p.banner; p.save() }
        Txt("صيغة البث المباشر (جرّب ts إذا لم تعمل m3u8)", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FocusButton("m3u8", selected = p.liveExt == "m3u8") { p.liveExt = "m3u8"; p.save() }
            FocusButton("ts", selected = p.liveExt == "ts") { p.liveExt = "ts"; p.save() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FocusButton("🔄 تحديث المحتوى") { onReload() }
            FocusButton("تسجيل الخروج") { onLogout() }
        }
    }
}
