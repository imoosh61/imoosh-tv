package com.najm.tv

import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

object Palette {
    val accents = listOf(Color(0xFFE50914), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFFB300), Color(0xFF8E24AA))
    val bgs = listOf(Color(0xFF141414), Color(0xFF000000), Color(0xFF0B1426))
}

/** آخر نقطة توقف لفيلم أو حلقة */
data class ResumeEntry(
    val itemKey: String, val url: String, val title: String,
    val pos: Long, val dur: Long, val updated: Long
)

class AppPrefs(private val sp: SharedPreferences) {
    var mode by mutableStateOf(sp.getString("mode", "") ?: "")
    var server by mutableStateOf(sp.getString("server", "") ?: "")
    var user by mutableStateOf(sp.getString("user", "") ?: "")
    var pass by mutableStateOf(sp.getString("pass", "") ?: "")
    var m3u by mutableStateOf(sp.getString("m3u", "") ?: "")
    var accent by mutableIntStateOf(sp.getInt("accent", 0))
    var bg by mutableIntStateOf(sp.getInt("bg", 0))
    var scale by mutableFloatStateOf(sp.getFloat("scale", 1f))
    var banner by mutableStateOf(sp.getBoolean("banner", true))
    var liveExt by mutableStateOf(sp.getString("liveExt", "m3u8") ?: "m3u8")
    val favorites = mutableStateListOf<String>().apply { addAll(sp.getStringSet("fav", emptySet()) ?: emptySet()) }
    val recent = mutableStateListOf<String>().apply {
        addAll((sp.getString("recent", "") ?: "").split("\n").filter { it.isNotEmpty() })
    }
    val resume = mutableStateListOf<ResumeEntry>().apply { addAll(loadResume()) }

    private fun loadResume(): List<ResumeEntry> = try {
        val a = JSONArray(sp.getString("resume", "[]"))
        List(a.length()) {
            val o = a.getJSONObject(it)
            ResumeEntry(o.getString("k"), o.getString("u"), o.getString("t"), o.getLong("p"), o.getLong("d"), o.getLong("m"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save() {
        sp.edit()
            .putString("mode", mode).putString("server", server).putString("user", user)
            .putString("pass", pass).putString("m3u", m3u)
            .putInt("accent", accent).putInt("bg", bg).putFloat("scale", scale)
            .putBoolean("banner", banner).putString("liveExt", liveExt)
            .putStringSet("fav", favorites.toSet())
            .putString("recent", recent.joinToString("\n"))
            .apply()
    }

    fun toggleFav(k: String) {
        if (!favorites.remove(k)) favorites.add(k)
        save()
    }

    fun addRecent(k: String) {
        recent.remove(k)
        recent.add(0, k)
        while (recent.size > 20) recent.removeAt(recent.lastIndex)
        save()
    }

    fun resumeFor(key: String?, url: String): ResumeEntry? =
        if (key == null) null else resume.firstOrNull { it.itemKey == key && it.url == url }

    fun saveResume(e: ResumeEntry) {
        resume.removeAll { it.itemKey == e.itemKey }
        // إذا شاف أكثر من 95% نعتبره منتهياً ونشيله من القائمة
        if (!(e.dur > 0 && e.pos > e.dur * 0.95)) resume.add(0, e)
        while (resume.size > 30) resume.removeAt(resume.lastIndex)
        val a = JSONArray()
        resume.forEach {
            a.put(JSONObject().put("k", it.itemKey).put("u", it.url).put("t", it.title)
                .put("p", it.pos).put("d", it.dur).put("m", it.updated))
        }
        sp.edit().putString("resume", a.toString()).apply()
    }
}
