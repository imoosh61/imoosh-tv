package com.najm.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.coroutineContext

enum class DlStatus { RUNNING, WAITING, PAUSED, DONE, FAILED }

data class DlItem(
    val id: String,
    val title: String,
    val url: String,
    val path: String,
    val total: Long,
    val done: Long,
    val status: DlStatus,
    val speed: Long = 0,
    val note: String = ""
)

/** مدير تنزيلات خاص: إيقاف مؤقت، مواصلة من نفس النقطة، إلغاء، سرعة، وإعادة محاولة تلقائية */
object DownloadCenter {
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val conns = ConcurrentHashMap<String, HttpURLConnection>()
    val state = MutableStateFlow<List<DlItem>>(emptyList())
    private var inited = false

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        try {
            val f = File(app.filesDir, "downloads.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                state.value = List(a.length()) {
                    val o = a.getJSONObject(it)
                    val st = DlStatus.valueOf(o.getString("s"))
                    DlItem(
                        o.getString("id"), o.getString("t"), o.getString("u"), o.getString("p"),
                        o.getLong("tot"), o.getLong("d"),
                        if (st == DlStatus.RUNNING) DlStatus.WAITING else st
                    )
                }
            }
        } catch (_: Exception) { }
    }

    private fun save() {
        try {
            val a = JSONArray()
            state.value.forEach {
                a.put(JSONObject().put("id", it.id).put("t", it.title).put("u", it.url).put("p", it.path)
                    .put("tot", it.total).put("d", it.done).put("s", it.status.name))
            }
            File(app.filesDir, "downloads.json").writeText(a.toString())
        } catch (_: Exception) { }
    }

    private fun update(id: String, f: (DlItem) -> DlItem) {
        state.update { l -> l.map { if (it.id == id) f(it) else it } }
    }

    private fun startService(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (_: Exception) { }
    }

    /** يستأنف أي تنزيل كان جارياً أو منتظراً عند فتح التطبيق */
    fun resumeAll() {
        var any = false
        state.value.filter { it.status == DlStatus.WAITING || it.status == DlStatus.RUNNING }.forEach {
            if (jobs[it.id]?.isActive != true) { startJob(it.id); any = true }
        }
        if (any) startService(app)
    }

    fun enqueue(ctx: Context, url: String, title: String, ext: String) {
        init(ctx)
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir
        val base = title.replace(Regex("[^\\p{L}\\p{N} ._-]"), "").trim().ifBlank { "video" }
        val id = System.currentTimeMillis().toString()
        val f = File(dir, "$base-${id.takeLast(5)}.$ext")
        state.update { listOf(DlItem(id, title, url, f.absolutePath, -1, 0, DlStatus.WAITING)) + it }
        save()
        startJob(id)
        startService(ctx)
        Toast.makeText(ctx, "أضيف للتنزيلات: $title", Toast.LENGTH_LONG).show()
    }

    fun pause(id: String) {
        update(id) { it.copy(status = DlStatus.PAUSED, speed = 0, note = "") }
        jobs.remove(id)?.cancel()
        scope.launch { conns[id]?.disconnect() }
        save()
    }

    fun resume(ctx: Context, id: String) {
        update(id) { it.copy(status = DlStatus.WAITING, note = "") }
        startJob(id)
        startService(ctx)
    }

    fun cancel(id: String) {
        val d = state.value.firstOrNull { it.id == id }
        jobs.remove(id)?.cancel()
        scope.launch {
            conns[id]?.disconnect()
            delay(300)
            d?.let { try { File(it.path).delete() } catch (_: Exception) { } }
        }
        state.update { l -> l.filter { it.id != id } }
        save()
    }

    private fun startJob(id: String) {
        jobs.remove(id)?.cancel()
        jobs[id] = scope.launch { download(id) }
    }

    private suspend fun download(id: String) {
        var failures = 0
        while (true) {
            coroutineContext.ensureActive()
            val d = state.value.firstOrNull { it.id == id } ?: return
            if (d.status == DlStatus.PAUSED || d.status == DlStatus.DONE) return
            val file = File(d.path)
            try {
                val have = if (file.exists()) file.length() else 0L
                update(id) { it.copy(status = DlStatus.RUNNING, note = "") }
                val c = URL(d.url).openConnection() as HttpURLConnection
                conns[id] = c
                try {
                    c.connectTimeout = 20000
                    c.readTimeout = 15000
                    c.setRequestProperty("User-Agent", "Mozilla/5.0")
                    if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
                    val code = c.responseCode
                    if (code == 416) {
                        update(id) { it.copy(status = DlStatus.DONE, total = have, done = have, speed = 0) }
                        save()
                        return
                    }
                    if (code in 400..499 && code != 408 && code != 429) {
                        update(id) { it.copy(status = DlStatus.FAILED, speed = 0, note = "رفض السيرفر (HTTP $code)") }
                        save()
                        return
                    }
                    if (code !in 200..299) throw IOException("HTTP $code")
                    val resumed = code == 206 && have > 0
                    val len = c.contentLengthLong
                    val total = if (len > 0) (if (resumed) have + len else len) else -1L
                    var done = if (resumed) have else 0L
                    update(id) { it.copy(total = total, done = done) }
                    FileOutputStream(file, resumed).use { out ->
                        c.inputStream.use { inp ->
                            val buf = ByteArray(65536)
                            var lastT = System.currentTimeMillis()
                            var lastBytes = done
                            var lastSave = lastT
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                coroutineContext.ensureActive()
                                out.write(buf, 0, n)
                                done += n
                                if (failures > 0) failures = 0
                                val now = System.currentTimeMillis()
                                if (now - lastT >= 700) {
                                    val speed = (done - lastBytes) * 1000 / (now - lastT)
                                    update(id) { it.copy(done = done, speed = speed, status = DlStatus.RUNNING, note = "") }
                                    lastT = now
                                    lastBytes = done
                                    if (now - lastSave > 5000) { save(); lastSave = now }
                                }
                            }
                        }
                    }
                    if (total > 0 && done < total) throw IOException("incomplete")
                    update(id) { it.copy(status = DlStatus.DONE, total = done, done = done, speed = 0, note = "") }
                    save()
                    return
                } finally {
                    conns.remove(id)
                    c.disconnect()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                coroutineContext.ensureActive()
                failures++
                if (failures > 20) {
                    update(id) { it.copy(status = DlStatus.FAILED, speed = 0, note = "تعذّر الاتصال بالسيرفر") }
                    save()
                    return
                }
                update(id) { it.copy(status = DlStatus.WAITING, speed = 0, note = "انقطع الاتصال، إعادة المحاولة تلقائياً...") }
                save()
                delay(minOf(3000L * failures, 15000L))
            }
        }
    }
}

class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notif(text: String): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "dl") else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return b.setSmallIcon(R.drawable.ic_launcher).setContentTitle("نجم TV").setContentText(text).setOngoing(true).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        DownloadCenter.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("dl", "التنزيلات", NotificationManager.IMPORTANCE_LOW))
        }
        val n = notif("جاري التنزيل...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
        DownloadCenter.resumeAll()
        scope.coroutineContext.cancelChildren()
        scope.launch {
            DownloadCenter.state.collect { l ->
                val active = l.filter { it.status == DlStatus.RUNNING || it.status == DlStatus.WAITING }
                if (active.isEmpty()) {
                    stopForeground(true)
                    stopSelf()
                } else {
                    val sp = active.sumOf { it.speed } / 1048576.0
                    nm.notify(1, notif("تنزيل ${active.size} ملف • " + String.format(java.util.Locale.US, "%.1f MB/s", sp)))
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
