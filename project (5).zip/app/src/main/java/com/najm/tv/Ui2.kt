package com.najm.tv

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val LocalGrid = compositionLocalOf { 1f }

fun secOf(t: Type): Section = when (t) {
    Type.MOVIE -> Repo.moviesSec
    Type.SERIES -> Repo.seriesSec
    Type.LIVE -> Repo.liveSec
}

@Composable
fun Avatar(pr: Profile, size: Dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(AVATAR_COLORS[pr.avatar % AVATAR_COLORS.size]),
        contentAlignment = Alignment.Center
    ) { Txt(AVATARS[pr.avatar % AVATARS.size], (size.value * 0.55f).toInt()) }
}

@Composable
fun AvatarButton(pr: Profile, size: Dp, modifier: Modifier = Modifier, selected: Boolean = false, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    Box(
        modifier
            .size(size + 8.dp)
            .clip(CircleShape)
            .border(3.dp, if (f) Color.White else if (selected) Color.Gray else Color.Transparent, CircleShape)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) { Avatar(pr, size) }
}

@Composable
fun IconBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (f) accent else Color.White.copy(alpha = 0.1f))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Txt(text, 20) }
}

@Composable
fun KeyBtn(text: String, onClick: () -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    Box(
        Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(if (f) accent else Color.White.copy(alpha = 0.1f))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Txt(text, 24, true) }
}

/** لوحة أرقام لرمز PIN من 4 خانات */
@Composable
fun PinPad(title: String, onDone: (String) -> Unit, onCancel: () -> Unit, error: String = "") {
    var pin by remember { mutableStateOf("") }
    LaunchedEffect(pin) {
        if (pin.length == 4) {
            val v = pin
            pin = ""
            onDone(v)
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Txt(title, 22, true)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(4) { i ->
                Box(Modifier.size(18.dp).clip(CircleShape).background(if (i < pin.length) Color.White else Color.Gray.copy(alpha = 0.5f)))
            }
        }
        if (error.isNotEmpty()) Txt(error, 14, color = Color(0xFFFF6B6B))
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "✖"))
        rows.forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                r.forEach { k ->
                    KeyBtn(k) {
                        if (k == "⌫") {
                            if (pin.isNotEmpty()) pin = pin.dropLast(1)
                        } else if (k == "✖") {
                            onCancel()
                        } else if (pin.length < 4) {
                            pin += k
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CycleButton(label: String, options: List<String>, index: Int, onChange: (Int) -> Unit) {
    FocusButton("$label: ${options[index.coerceIn(0, options.lastIndex)]} ▾") { onChange((index + 1) % options.size) }
}
