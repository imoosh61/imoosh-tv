package com.najm.tv

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/** تقسيم الشاشة: من 2 إلى 4 قنوات، الصوت للقناة المحددة (تنقّل بالأسهم لتغيير الصوت) */
class MultiViewActivity : AppCompatActivity() {
    private val players = ArrayList<ExoPlayer>()
    private val cells = ArrayList<FrameLayout>()

    private fun select(idx: Int) {
        players.forEachIndexed { i, p -> p.volume = if (i == idx) 1f else 0f }
        cells.forEachIndexed { i, c -> c.setBackgroundColor(if (i == idx) Color.rgb(229, 9, 20) else Color.TRANSPARENT) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val urls = intent.getStringArrayListExtra("urls")?.take(4) ?: run { finish(); return }
        val http = DefaultHttpDataSource.Factory().setUserAgent("Mozilla/5.0").setAllowCrossProtocolRedirects(true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        urls.chunked(2).forEachIndexed { r, rowUrls ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowUrls.forEachIndexed { c, u ->
                val idx = r * 2 + c
                val p = ExoPlayer.Builder(this)
                    .setMediaSourceFactory(DefaultMediaSourceFactory(http))
                    .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(5000, 20000, 1500, 3000).build())
                    .build()
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setMaxVideoSize(1280, 720).build()
                val v = PlayerView(this).apply {
                    useController = false
                    player = p
                }
                val cell = FrameLayout(this).apply {
                    isFocusable = true
                    isClickable = true
                    setPadding(4, 4, 4, 4)
                    setOnClickListener { select(idx) }
                    setOnFocusChangeListener { _, has -> if (has) select(idx) }
                    addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                players.add(p)
                cells.add(cell)
                p.setMediaItem(MediaItem.fromUri(u))
                p.prepare()
                p.playWhenReady = true
            }
            // إذا كانت 3 قنوات نضيف خلية فارغة لتوازن الصف الأخير
            if (rowUrls.size == 1 && urls.size > 2) {
                row.addView(View(this), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        select(0)
        cells.firstOrNull()?.requestFocus()
    }

    override fun onStop() {
        players.forEach { it.pause() }
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        players.forEach { it.play() }
    }

    override fun onDestroy() {
        players.forEach { it.release() }
        players.clear()
        super.onDestroy()
    }
}
