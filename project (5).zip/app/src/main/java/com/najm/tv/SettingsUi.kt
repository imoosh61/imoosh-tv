package com.najm.tv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AccountCard(p: AppPrefs) {
    var acc by remember { mutableStateOf<Account?>(null) }
    var state by remember { mutableStateOf("loading") }
    var ms by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        if (p.mode == "m3u") {
            state = "none"
        } else {
            try {
                val t0 = System.currentTimeMillis()
                val a = Repo.account()
                ms = System.currentTimeMillis() - t0
                acc = a
                state = if (a != null) "ok" else "none"
            } catch (e: Exception) {
                state = "error"
            }
        }
    }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.US) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.07f)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Txt("📋 تفاصيل الاشتراك", 18, true)
        val a = acc
        when {
            state == "loading" -> Txt("جاري التحميل...", 14, color = Color.Gray)
            state == "none" -> Txt("تفاصيل الاشتراك غير متاحة مع روابط M3U", 14, color = Color.Gray)
            state == "error" || a == null -> Txt("تعذّر جلب بيانات الاشتراك: السيرفر لا يستجيب", 14, color = Color(0xFFFF6B6B))
            else -> {
                val now = System.currentTimeMillis() / 1000
                val active = a.status.equals("Active", true)
                Txt("الحالة: " + (if (active) "فعّال ✓" else a.status) + (if (a.trial) " (تجريبي)" else ""), 15)
                Txt("تاريخ البدء: " + (if (a.created > 0) fmt.format(Date(a.created * 1000)) else "—"), 15)
                if (a.expires > 0) {
                    val days = (a.expires - now) / 86400
                    Txt("تاريخ الانتهاء: " + fmt.format(Date(a.expires * 1000)), 15)
                    Txt(
                        "الأيام المتبقية: " + (if (days >= 0) "$days يوم" else "منتهي"),
                        15, true, if (days in 0..7) Color(0xFFFFB300) else if (days < 0) Color(0xFFFF6B6B) else Color(0xFF66BB6A)
                    )
                } else {
                    Txt("تاريخ الانتهاء: غير محدود", 15)
                }
                Txt("الاتصالات: ${a.active} من ${a.max}", 15)
                Txt("حالة السيرفر: متصل ✓ (${ms}ms)", 15)
                Txt(a.serverUrl, 12, color = Color.Gray, maxLines = 1)
            }
        }
    }
}

@Composable
fun SettingsScreen(p: AppPrefs, onReload: () -> Unit, onLogout: () -> Unit, onProfiles: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 40.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AccountCard(p)
        FocusButton("👥 إدارة الملفات الشخصية") { onProfiles() }

        Txt("لون التطبيق", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Palette.accents.forEachIndexed { i, c -> ColorDot(c, p.accent == i) { p.accent = i; p.save() } }
        }
        Txt("لون الخلفية", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("رمادي داكن", "أسود", "أزرق ليلي").forEachIndexed { i, n ->
                FocusButton(n, selected = p.bg == i) { p.bg = i; p.save() }
            }
        }
        Txt("حجم الخط", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("صغير" to 0.85f, "عادي" to 1f, "كبير" to 1.2f).forEach { (n, s) ->
                FocusButton(n, selected = p.scale == s) { p.scale = s; p.save() }
            }
        }
        Txt("حجم الشبكة (حجم البطاقات)", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("صغير", "عادي", "كبير").forEachIndexed { i, n ->
                FocusButton(n, selected = p.gridScale == i) { p.gridScale = i; p.save() }
            }
        }
        Txt("البانر الكبير في أعلى الصفحات", 16, color = Color.LightGray)
        FocusButton(if (p.banner) "مفعّل" else "معطّل") { p.banner = !p.banner; p.save() }

        Txt("صيغة البث المباشر (جرّب ts إذا لم تعمل m3u8)", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FocusButton("m3u8", selected = p.liveExt == "m3u8") { p.liveExt = "m3u8"; p.save() }
            FocusButton("ts", selected = p.liveExt == "ts") { p.liveExt = "ts"; p.save() }
        }
        Txt("حجز الذاكرة المؤقتة للمشغّل (زِدها إذا كان البث يتقطع)", 16, color = Color.LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("صغير", "متوسط", "كبير").forEachIndexed { i, n ->
                FocusButton(n, selected = p.bufferMode == i) { p.bufferMode = i; p.save() }
            }
        }

        Txt("مفتاح TMDB لجلب القصة والتقييم وطاقم التمثيل والإعلان (اختياري، مجاني من themoviedb.org)", 16, color = Color.LightGray)
        Field("TMDB API Key", p.tmdbKey) { p.tmdbKey = it.trim(); p.save() }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FocusButton("🔄 تحديث المحتوى من السيرفر") { onReload() }
            FocusButton("تسجيل الخروج") { onLogout() }
        }
        Spacer(Modifier.height(16.dp))
        Txt("imoosh-tv © جميع الحقوق محفوظة - imoosh61", 14, color = Color.Gray)
    }
}
