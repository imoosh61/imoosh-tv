package com.najm.tv

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun Detail(p: AppPrefs, item: Item) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    var info by remember { mutableStateOf<SeriesInfo?>(null) }
    var epg by remember { mutableStateOf<List<Epg>>(emptyList()) }
    var progs by remember { mutableStateOf<List<Prog>>(emptyList()) }
    var tm by remember { mutableStateOf<Tmdb?>(null) }
    var season by remember { mutableIntStateOf(-1) }

    LaunchedEffect(item.key) {
        if (item.type == Type.SERIES) {
            info = try { Repo.seriesInfo(item) } catch (e: Exception) { SeriesInfo("تعذّر تحميل الحلقات", emptyList()) }
        }
    }
    LaunchedEffect(item.key + "epg") {
        if (item.type == Type.LIVE && item.url == null) {
            epg = try { Repo.epg(item) } catch (e: Exception) { emptyList() }
            progs = try {
                val now = System.currentTimeMillis() / 1000
                Repo.epgTable(item).filter { it.archive && it.end < now && it.start > now - 72 * 3600 }
                    .sortedByDescending { it.start }.take(12)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    LaunchedEffect(item.key + "tmdb") {
        if (item.type != Type.LIVE && p.tmdbKey.isNotBlank()) tm = Repo.tmdb(item, p.tmdbKey)
    }

    val fav = item.key in p.favorites
    val plot = tm?.overview?.takeIf { it.isNotBlank() } ?: (if (item.type == Type.SERIES) (info?.plot ?: item.plot) else item.plot)
    val rate = tm?.rating?.takeIf { it.isNotBlank() } ?: item.rating.takeIf { it.isNotBlank() && it != "0" }
    val meta = listOfNotNull(
        item.category,
        item.year.takeIf { it > 0 }?.toString(),
        rate?.let { "★ $it" }
    ).joinToString("  •  ")
    val eps = info?.episodes
    val seasons = eps?.map { it.season }?.distinct() ?: emptyList()
    val cur = if (season in seasons) season else (seasons.firstOrNull() ?: 1)
    val seasonEps = eps?.filter { it.season == cur } ?: emptyList()

    Row(Modifier.fillMaxSize().padding(40.dp)) {
        Box(Modifier.width(220.dp).height(320.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2A2A2A))) {
            val dreq = rememberImg(item.poster, 440, 640)
            if (dreq != null) {
                AsyncImage(
                    model = dreq, contentDescription = null,
                    contentScale = if (item.type == Type.LIVE) ContentScale.Fit else ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(32.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item(key = "#head") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Txt(item.title, 30, true, maxLines = 2)
                    Txt(meta, 15, color = Color.LightGray)
                    if (plot.isNotBlank()) Txt(plot, 14, color = Color.LightGray, maxLines = 4)
                    val cast = tm?.cast
                    if (!cast.isNullOrEmpty()) Txt("طاقم التمثيل: " + cast.joinToString("، "), 13, color = Color.Gray, maxLines = 2)
                    if (epg.isNotEmpty()) {
                        Txt("الآن: ${epg[0].start}–${epg[0].end}  ${epg[0].title}", 15, true, accent, maxLines = 1)
                        if (epg.size > 1) Txt("التالي: ${epg[1].start}–${epg[1].end}  ${epg[1].title}", 14, color = Color.LightGray, maxLines = 1)
                    }
                }
            }
            item(key = "#actions") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (item.type == Type.SERIES) {
                        p.resume.firstOrNull { it.itemKey == item.key }?.let { e ->
                            FocusButton("▶ متابعة (${fmtTime(e.pos)})", filled = true) { play(ctx, p, item.key, e.url, e.title) }
                        }
                    } else {
                        val url = Repo.playUrl(item)
                        val live = item.type == Type.LIVE
                        val saved = p.resumeFor(item.key, url)
                        if (saved != null && !live) {
                            FocusButton("▶ متابعة من ${fmtTime(saved.pos)}", filled = true) { play(ctx, p, item.key, url, item.title) }
                            FocusButton("⏮ من البداية") { play(ctx, p, item.key, url, item.title, fromStart = true) }
                        } else {
                            FocusButton("▶ تشغيل", filled = true) { play(ctx, p, item.key, url, item.title, live = live) }
                        }
                    }
                    if (item.type == Type.MOVIE) {
                        FocusButton("⬇ تنزيل") { DownloadCenter.enqueue(ctx, Repo.playUrl(item), item.title, item.ext) }
                    }
                    tm?.trailer?.let { k ->
                        FocusButton("🎞 الإعلان") {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$k")))
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "لا يوجد تطبيق يفتح الإعلان", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    FocusButton(if (fav) "★ إزالة من المفضلة" else "☆ إضافة للمفضلة") { p.toggleFav(item.key) }
                }
            }
            if (item.type == Type.LIVE) {
                item(key = "#multi") {
                    val inMulti = item.key in p.multi
                    FocusButton(if (inMulti) "▦ إزالة من المشاهدة المتعددة (${p.multi.size}/4)" else "▦ أضف للمشاهدة المتعددة (${p.multi.size}/4)") {
                        if (inMulti) {
                            p.multi.remove(item.key)
                        } else if (p.multi.size >= 4) {
                            Toast.makeText(ctx, "الحد الأقصى 4 قنوات", Toast.LENGTH_SHORT).show()
                        } else {
                            p.multi.add(item.key)
                        }
                    }
                }
                if (progs.isNotEmpty()) {
                    item(key = "#cu") { Txt("⏪ إعادة ما فات (آخر 72 ساعة)", 16, true) }
                    items(progs) { pr ->
                        val t = if (pr.startStr.length >= 16) pr.startStr.substring(11, 16) else ""
                        FocusButton("⏪ $t  ${pr.title}") {
                            play(ctx, p, null, Repo.timeshiftUrl(item, pr), pr.title)
                        }
                    }
                }
            }
            if (item.type == Type.SERIES) {
                if (eps == null) {
                    item(key = "#load") { Txt("جاري تحميل الحلقات...", 15, color = Color.Gray) }
                } else {
                    if (seasons.size > 1) {
                        item(key = "#seasons") {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(seasons, key = { it }) { s -> FocusButton("الموسم $s", selected = s == cur) { season = s } }
                            }
                        }
                    }
                    items(seasonEps, key = { "${it.season}-${it.num}-${it.id}" }) { e ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FocusButton("▶ ح${e.num}  ${e.title}") {
                                play(ctx, p, item.key, Repo.episodeUrl(e), "${item.title} - ${e.title}")
                            }
                            FocusButton("⬇") {
                                DownloadCenter.enqueue(ctx, Repo.episodeUrl(e), "${item.title} م${e.season} ح${e.num}", e.ext)
                            }
                        }
                    }
                }
            }
        }
    }
}
