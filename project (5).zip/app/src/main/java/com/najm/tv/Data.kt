package com.najm.tv

import android.content.Context
import android.util.Base64
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

enum class Type { LIVE, MOVIE, SERIES }

data class Item(
    val id: String,
    val title: String,
    val poster: String?,
    val category: String,
    val type: Type,
    val added: Long = 0,
    val rating: String = "",
    val ext: String = "mp4",
    val url: String? = null,
    val plot: String = "",
    val year: Int = 0
) {
    val key: String = "${type.name}:$id"
}

data class Episode(val id: String, val title: String, val season: Int, val num: Int, val ext: String, val url: String?)
data class Epg(val title: String, val start: String, val end: String)
data class SeriesInfo(val plot: String, val episodes: List<Episode>)
data class Prog(val title: String, val start: Long, val end: Long, val startStr: String, val archive: Boolean)
data class Account(val status: String, val created: Long, val expires: Long, val active: Int, val max: Int, val serverUrl: String, val trial: Boolean)
data class Tmdb(val overview: String, val rating: String, val cast: List<String>, val trailer: String?)

/** بيانات كل قسم محسوبة مسبقاً في الخلفية حتى يكون التنقل سريعاً */
class Section(val items: List<Item>) {
    val cats: List<Pair<String, List<Item>>> = items.groupBy { it.category }.toList()
    val newest: List<Item> = items.sortedByDescending { it.added }.take(80)
}

private val adultWords = listOf("xxx", "adult", "18+", "+18", "porn", "للكبار")
fun adultCat(name: String): Boolean {
    val l = name.lowercase()
    return adultWords.any { it in l }
}

private val yearRe = Regex("\\b(19[5-9]\\d|20[0-3]\\d)\\b")
private fun yearOf(vararg s: String): Int = s.firstNotNullOfOrNull { yearRe.find(it)?.value?.toInt() } ?: 0

private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

object Repo {
    lateinit var prefs: AppPrefs
    lateinit var appCtx: Context
    var forceRefresh = false
    private var cacheKey = ""

    fun ensurePrefs(ctx: Context): AppPrefs {
        if (!::prefs.isInitialized) prefs = AppPrefs(ctx.applicationContext.getSharedPreferences("najm", Context.MODE_PRIVATE))
        return prefs
    }

    private fun cacheFile(name: String): File {
        val dir = File(appCtx.cacheDir, "data").apply { mkdirs() }
        return File(dir, "${cacheKey}_$name.json")
    }

    private fun hasCache(name: String) = cacheFile(name).exists()

    /** تخزين مؤقت لبيانات السيرفر لمدة 12 ساعة حتى يفتح التطبيق بسرعة */
    private fun cached(name: String, loader: () -> String): String {
        val f = cacheFile(name)
        if (!forceRefresh && f.exists() && System.currentTimeMillis() - f.lastModified() < 12 * 3600 * 1000L) {
            try { return f.readText() } catch (_: Exception) { }
        }
        val t = loader()
        val head = t.trimStart().take(1)
        if (head == "[" || head == "#") {
            try { f.writeText(t) } catch (_: Exception) { }
        }
        return t
    }
    var server = ""
    var user = ""
    var pass = ""
    var movies: List<Item> = emptyList()
    var series: List<Item> = emptyList()
    var live: List<Item> = emptyList()
    var all: List<Item> = emptyList()
    var byKey: Map<String, Item> = emptyMap()
    var moviesSec = Section(emptyList())
    var seriesSec = Section(emptyList())
    var liveSec = Section(emptyList())

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(url: String, readTimeout: Int = 90000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = readTimeout
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun base() = "$server/player_api.php?username=${enc(user)}&password=${enc(pass)}"
    private fun api(action: String, extra: String = "") = get("${base()}&action=$action$extra")

    suspend fun load(p: AppPrefs) {
        withContext(Dispatchers.IO) {
            prefs = p
            if (p.mode == "m3u") {
                cacheKey = p.m3u.trim().hashCode().toString()
                loadM3u(cached("m3u") { get(p.m3u.trim()) })
            } else {
                server = pickServer(p)
                user = p.user.trim()
                pass = p.pass.trim()
                cacheKey = "$server|$user".hashCode().toString()
                loadXtream()
            }
            all = movies + series + live
            byKey = all.associateBy { it.key }
            moviesSec = Section(movies)
            seriesSec = Section(series)
            liveSec = Section(live)
            forceRefresh = false
            Unit
        }
    }

    private fun norm(s: String) = s.trim().let { if (it.startsWith("http")) it else "http://$it" }.trimEnd('/')

    /** المرشحون: رابط مباشر، أو رقم من قائمة السيرفرات، أو كل القائمة (بحث تلقائي) */
    private fun candidates(p: AppPrefs): List<String> {
        val v = p.server.trim()
        val list = p.serverList()
        return when {
            v.isEmpty() -> list
            v.length <= 3 && v.all { it.isDigit() } -> listOfNotNull(list.getOrNull(v.toInt() - 1))
            else -> listOf(norm(v))
        }
    }

    private fun pickServer(p: AppPrefs): String {
        val c = candidates(p)
        if (c.isEmpty()) {
            throw Exception(if (p.server.isBlank()) "اكتب رابط السيرفر أو أضف قائمة السيرفرات" else "رقم السيرفر غير موجود في القائمة")
        }
        if (c.size == 1) return c[0]
        if (p.resolved in c) return p.resolved
        val u = enc(p.user.trim())
        val pw = enc(p.pass.trim())
        for (s in c) {
            try {
                val o = JSONObject(get("$s/player_api.php?username=$u&password=$pw", 8000))
                if (o.optJSONObject("user_info")?.optInt("auth", 0) == 1) {
                    p.resolved = s
                    p.save()
                    return s
                }
            } catch (_: Exception) { }
        }
        throw Exception("لم أجد سيرفراً يقبل هذا الحساب. تأكد من اليوزر والباسورد وقائمة السيرفرات")
    }

    private suspend fun loadXtream() = coroutineScope {
        try {
            val auth = JSONObject(get(base()))
            if (auth.optJSONObject("user_info")?.optInt("auth", 0) != 1) throw Exception("بيانات الدخول غير صحيحة")
        } catch (e: java.io.IOException) {
            // بدون إنترنت: نكمل من الكاش إذا موجود
            if (!hasCache("vod_streams")) throw e
        }
        val vc = async { cats(cached("vod_cat") { api("get_vod_categories") }) }
        val sc = async { cats(cached("series_cat") { api("get_series_categories") }) }
        val lc = async { cats(cached("live_cat") { api("get_live_categories") }) }
        val vs = async { JSONArray(cached("vod_streams") { api("get_vod_streams") }) }
        val ss = async { JSONArray(cached("series") { api("get_series") }) }
        val ls = async { JSONArray(cached("live_streams") { api("get_live_streams") }) }
        val vcm = vc.await(); val scm = sc.await(); val lcm = lc.await()
        movies = parse(vs.await(), vcm, Type.MOVIE)
        series = parse(ss.await(), scm, Type.SERIES)
        live = parse(ls.await(), lcm, Type.LIVE)
    }

    private fun cats(txt: String): Map<String, String> {
        val a = JSONArray(txt)
        val m = HashMap<String, String>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            m[o.str("category_id")] = o.str("category_name")
        }
        return m
    }

    private fun parse(a: JSONArray, c: Map<String, String>, t: Type): List<Item> = List(a.length()) { i ->
        val o = a.getJSONObject(i)
        when (t) {
            Type.MOVIE -> Item(
                id = o.str("stream_id"), title = o.str("name"),
                poster = o.str("stream_icon").ifBlank { null },
                category = c[o.str("category_id")] ?: "أخرى", type = t,
                added = o.str("added").toLongOrNull() ?: 0, rating = o.str("rating"),
                ext = o.str("container_extension").ifBlank { "mp4" },
                year = yearOf(o.str("name"), o.str("year"))
            )
            Type.SERIES -> Item(
                id = o.str("series_id"), title = o.str("name"),
                poster = o.str("cover").ifBlank { null },
                category = c[o.str("category_id")] ?: "أخرى", type = t,
                added = o.str("last_modified").toLongOrNull() ?: 0, rating = o.str("rating"),
                plot = o.str("plot"),
                year = yearOf(o.str("name"), o.str("releaseDate"), o.str("release_date"))
            )
            Type.LIVE -> Item(
                id = o.str("stream_id"), title = o.str("name"),
                poster = o.str("stream_icon").ifBlank { null },
                category = c[o.str("category_id")] ?: "أخرى", type = t
            )
        }
    }

    private fun loadM3u(text: String) {
        val m = mutableListOf<Item>(); val s = mutableListOf<Item>(); val l = mutableListOf<Item>()
        var title = ""; var logo: String? = null; var group = "أخرى"; var n = 0
        val logoRe = Regex("tvg-logo=\"([^\"]*)\"")
        val groupRe = Regex("group-title=\"([^\"]*)\"")
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                title = line.substringAfterLast(",").trim()
                logo = logoRe.find(line)?.groupValues?.get(1)?.ifBlank { null }
                group = groupRe.find(line)?.groupValues?.get(1)?.ifBlank { null } ?: "أخرى"
            } else if (line.isNotEmpty() && !line.startsWith("#")) {
                val low = line.substringBefore('?').lowercase()
                val ext = low.substringAfterLast('.', "")
                val type = when {
                    "/series/" in low -> Type.SERIES
                    "/movie/" in low || ext in setOf("mp4", "mkv", "avi", "mov") -> Type.MOVIE
                    else -> Type.LIVE
                }
                val item = Item(
                    id = (n++).toString(), title = title.ifBlank { "بدون اسم" }, poster = logo,
                    category = group, type = type, ext = if (ext.length in 2..4) ext else "mp4", url = line,
                    year = yearOf(title)
                )
                when (type) { Type.MOVIE -> m += item; Type.SERIES -> s += item; Type.LIVE -> l += item }
            }
        }
        movies = m; series = s; live = l
    }

    fun playUrl(i: Item): String = i.url ?: when (i.type) {
        Type.LIVE -> "$server/live/$user/$pass/${i.id}.${prefs.liveExt}"
        Type.MOVIE -> "$server/movie/$user/$pass/${i.id}.${i.ext}"
        Type.SERIES -> ""
    }

    fun episodeUrl(e: Episode): String = e.url ?: "$server/series/$user/$pass/${e.id}.${e.ext}"

    suspend fun seriesInfo(i: Item): SeriesInfo = withContext(Dispatchers.IO) {
        if (i.url != null) return@withContext SeriesInfo(i.plot, listOf(Episode(i.id, i.title, 1, 1, i.ext, i.url)))
        val root = JSONObject(api("get_series_info", "&series_id=${i.id}"))
        val out = mutableListOf<Episode>()
        fun add(season: Int, a: JSONArray) {
            for (k in 0 until a.length()) {
                val o = a.getJSONObject(k)
                val num = o.optInt("episode_num", k + 1)
                out += Episode(
                    o.str("id"), o.str("title").ifBlank { "حلقة $num" },
                    o.optInt("season", season), num,
                    o.str("container_extension").ifBlank { "mp4" }, null
                )
            }
        }
        when (val eps = root.opt("episodes")) {
            is JSONObject -> eps.keys().forEach { key -> eps.optJSONArray(key)?.let { add(key.toIntOrNull() ?: 1, it) } }
            is JSONArray -> for (x in 0 until eps.length()) eps.optJSONArray(x)?.let { add(x + 1, it) }
        }
        out.sortWith(compareBy({ it.season }, { it.num }))
        SeriesInfo(root.optJSONObject("info")?.str("plot") ?: "", out)
    }

    suspend fun epg(i: Item): List<Epg> = withContext(Dispatchers.IO) {
        val o = JSONObject(api("get_short_epg", "&stream_id=${i.id}&limit=3"))
        val a = o.optJSONArray("epg_listings") ?: return@withContext emptyList()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        fun dec(t: String): String = try {
            String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8)
        } catch (e: Exception) {
            t
        }
        List(a.length()) { k ->
            val e = a.getJSONObject(k)
            val st = e.str("start_timestamp").toLongOrNull() ?: 0L
            val en = e.str("stop_timestamp").toLongOrNull() ?: 0L
            Epg(dec(e.str("title")), fmt.format(Date(st * 1000)), fmt.format(Date(en * 1000)))
        }
    }

    // ---------- معلومات الاشتراك ----------

    suspend fun account(): Account? = withContext(Dispatchers.IO) {
        if (prefs.mode == "m3u" || server.isEmpty()) return@withContext null
        val o = JSONObject(get(base(), 15000))
        val u = o.optJSONObject("user_info") ?: return@withContext null
        Account(
            status = u.str("status"),
            created = u.str("created_at").toLongOrNull() ?: 0L,
            expires = u.str("exp_date").toLongOrNull() ?: 0L,
            active = u.str("active_cons").toIntOrNull() ?: 0,
            max = u.str("max_connections").toIntOrNull() ?: 0,
            serverUrl = server,
            trial = u.str("is_trial") == "1"
        )
    }

    // ---------- الإعادة (Catch-up) ----------

    suspend fun epgTable(i: Item): List<Prog> = withContext(Dispatchers.IO) {
        val o = JSONObject(api("get_simple_data_table", "&stream_id=${i.id}"))
        val a = o.optJSONArray("epg_listings") ?: return@withContext emptyList()
        fun dec(t: String): String = try {
            String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8)
        } catch (e: Exception) {
            t
        }
        List(a.length()) { k ->
            val e = a.getJSONObject(k)
            Prog(
                dec(e.str("title")),
                e.str("start_timestamp").toLongOrNull() ?: 0L,
                e.str("stop_timestamp").toLongOrNull() ?: 0L,
                e.str("start"),
                e.optInt("has_archive", 0) == 1
            )
        }
    }

    fun timeshiftUrl(i: Item, p: Prog): String {
        val s = p.startStr.take(16)
        val stamp = if (s.length == 16) s.substring(0, 10) + ":" + s.substring(11, 13) + "-" + s.substring(14, 16) else s
        val minutes = ((p.end - p.start) / 60).coerceAtLeast(1)
        return "$server/timeshift/$user/$pass/$minutes/$stamp/${i.id}.ts"
    }

    // ---------- TMDB ----------

    private val tmdbCache = HashMap<String, Tmdb?>()

    private fun cleanTitle(t: String): String = t
        .replace(Regex("[\\(\\[].*?[\\)\\]]"), " ")
        .replace(yearRe, " ")
        .replace(Regex("^[A-Za-z]{2,3}\\s*[|:-]\\s*"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    suspend fun tmdb(item: Item, key: String): Tmdb? = withContext(Dispatchers.IO) {
        if (tmdbCache.containsKey(item.key)) return@withContext tmdbCache[item.key]
        val res: Tmdb? = try {
            val kind = if (item.type == Type.SERIES) "tv" else "movie"
            val k = enc(key.trim())
            val q = enc(cleanTitle(item.title))
            val s = JSONObject(get("https://api.themoviedb.org/3/search/$kind?api_key=$k&language=ar&query=$q", 15000))
            val id = s.optJSONArray("results")?.optJSONObject(0)?.optInt("id", 0) ?: 0
            if (id == 0) {
                null
            } else {
                val d = JSONObject(get("https://api.themoviedb.org/3/$kind/$id?api_key=$k&language=ar&append_to_response=credits,videos&include_video_language=en,ar,null", 15000))
                val cast = ArrayList<String>()
                val ca = d.optJSONObject("credits")?.optJSONArray("cast")
                if (ca != null) for (n in 0 until minOf(ca.length(), 6)) cast.add(ca.getJSONObject(n).str("name"))
                var trailer: String? = null
                val va = d.optJSONObject("videos")?.optJSONArray("results")
                if (va != null) {
                    for (n in 0 until va.length()) {
                        val v = va.getJSONObject(n)
                        if (v.str("site") == "YouTube" && v.str("type") == "Trailer") { trailer = v.str("key"); break }
                    }
                }
                val r = d.optDouble("vote_average", 0.0)
                Tmdb(d.str("overview"), if (r > 0) String.format(Locale.US, "%.1f", r) else "", cast, trailer)
            }
        } catch (e: Exception) {
            null
        }
        tmdbCache[item.key] = res
        res
    }
}
