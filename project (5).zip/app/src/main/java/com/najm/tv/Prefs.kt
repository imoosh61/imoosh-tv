package com.najm.tv

import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

object Palette {
    val accents = listOf(Color(0xFFE50914), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFFB300), Color(0xFF8E24AA))
    val bgs = listOf(Color(0xFF141414), Color(0xFF000000), Color(0xFF0B1426))
}

val AVATARS = listOf("🐼", "🦁", "🦊", "🐯", "🐸", "🦄", "🐵", "🐰")
val AVATAR_COLORS = listOf(
    Color(0xFF2E7D32), Color(0xFFF9A825), Color(0xFFEF6C00), Color(0xFFC62828),
    Color(0xFF00897B), Color(0xFF8E24AA), Color(0xFF6D4C41), Color(0xFFEC407A)
)

data class Profile(val id: String, val name: String, val avatar: Int, val pin: String = "", val kids: Boolean = false)

/** آخر نقطة توقف لفيلم أو حلقة */
data class ResumeEntry(
    val itemKey: String, val url: String, val title: String,
    val pos: Long, val dur: Long, val updated: Long
)

class AppPrefs(private val sp: SharedPreferences) {
    var mode by mutableStateOf(sp.getString("mode", "") ?: "")
    var server by mutableStateOf(sp.getString("server", "") ?: "")
    var user by mutableStateOf(sp.getString("user", "") ?: "")
    var pass by mutableStateOf(sp.getString("pass", "") ?: "")
    var m3u by mutableStateOf(sp.getString("m3u", "") ?: "")
    var accent by mutableIntStateOf(sp.getInt("accent", 0))
    var bg by mutableIntStateOf(sp.getInt("bg", 0))
    var scale by mutableFloatStateOf(sp.getFloat("scale", 1f))
    var banner by mutableStateOf(sp.getBoolean("banner", true))
    var servers by mutableStateOf(sp.getString("servers", "") ?: "")
    var resolved by mutableStateOf(sp.getString("resolved", "") ?: "")
    var liveExt by mutableStateOf(sp.getString("liveExt", "m3u8") ?: "m3u8")
    /** حجم الشبكة: 0 صغير، 1 عادي، 2 كبير */
    var gridScale by mutableIntStateOf(sp.getInt("grid", 1))
    /** حجز الذاكرة: 0 صغير، 1 متوسط، 2 كبير */
    var bufferMode by mutableIntStateOf(sp.getInt("buffer", 1))
    var tmdbKey by mutableStateOf(sp.getString("tmdb", "") ?: "")

    val profiles = mutableStateListOf<Profile>()
    var activeId by mutableStateOf("")
    /** هل اختار المستخدم ملفاً في هذه الجلسة (لا يُحفظ) */
    var profileChosen by mutableStateOf(false)

    val favorites = mutableStateListOf<String>()
    val recent = mutableStateListOf<String>()
    val resume = mutableStateListOf<ResumeEntry>()
    /** قنوات المشاهدة المتعددة (للجلسة فقط) */
    val multi = mutableStateListOf<String>()

    init {
        loadProfiles()
        loadProfileData()
    }

    val active: Profile get() = profiles.firstOrNull { it.id == activeId } ?: profiles.first()

    // ---------- الملفات الشخصية ----------

    private fun loadProfiles() {
        try {
            val a = JSONArray(sp.getString("profiles", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                profiles.add(Profile(o.getString("id"), o.getString("n"), o.optInt("a", 0), o.optString("p", ""), o.optBoolean("k", false)))
            }
        } catch (_: Exception) { }
        if (profiles.isEmpty()) {
            profiles.add(Profile("p1", "imoosh", 0))
            saveProfiles()
        }
        val saved = sp.getString("active", "") ?: ""
        activeId = if (profiles.any { it.id == saved }) saved else profiles.first().id
    }

    private fun saveProfiles() {
        val a = JSONArray()
        profiles.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("a", it.avatar).put("p", it.pin).put("k", it.kids)) }
        sp.edit().putString("profiles", a.toString()).putString("active", activeId).apply()
    }

    private fun loadProfileData() {
        val id = activeId
        favorites.clear()
        val legacyFav = if (id == "p1") sp.getStringSet("fav", emptySet()) else emptySet<String>()
        favorites.addAll(sp.getStringSet("fav_$id", legacyFav) ?: emptySet())
        recent.clear()
        val legacyRecent = if (id == "p1") (sp.getString("recent", "") ?: "") else ""
        recent.addAll((sp.getString("recent_$id", legacyRecent) ?: "").split("\n").filter { it.isNotEmpty() })
        resume.clear()
        val legacyResume = if (id == "p1") (sp.getString("resume", "[]") ?: "[]") else "[]"
        resume.addAll(parseResume(sp.getString("resume_$id", legacyResume) ?: "[]"))
    }

    private fun parseResume(txt: String): List<ResumeEntry> = try {
        val a = JSONArray(txt)
        List(a.length()) {
            val o = a.getJSONObject(it)
            ResumeEntry(o.getString("k"), o.getString("u"), o.getString("t"), o.getLong("p"), o.getLong("d"), o.getLong("m"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun switchTo(id: String) {
        if (id == activeId) return
        save()
        activeId = id
        sp.edit().putString("active", id).apply()
        loadProfileData()
    }

    fun addProfile(name: String, avatar: Int, pin: String, kids: Boolean) {
        profiles.add(Profile("p" + System.currentTimeMillis(), name.ifBlank { "ملف جديد" }, avatar, pin, kids))
        saveProfiles()
    }

    fun updateProfile(p: Profile) {
        val i = profiles.indexOfFirst { it.id == p.id }
        if (i >= 0) profiles[i] = p
        saveProfiles()
    }

    fun deleteProfile(id: String) {
        if (profiles.size <= 1) return
        profiles.removeAll { it.id == id }
        sp.edit().remove("fav_$id").remove("recent_$id").remove("resume_$id").apply()
        if (activeId == id) {
            activeId = profiles.first().id
            loadProfileData()
        }
        saveProfiles()
    }

    // ---------- الحفظ ----------

    fun save() {
        sp.edit()
            .putString("mode", mode).putString("server", server).putString("user", user)
            .putString("pass", pass).putString("m3u", m3u)
            .putInt("accent", accent).putInt("bg", bg).putFloat("scale", scale)
            .putBoolean("banner", banner).putString("liveExt", liveExt)
            .putString("servers", servers).putString("resolved", resolved)
            .putInt("grid", gridScale).putInt("buffer", bufferMode).putString("tmdb", tmdbKey)
            .putStringSet("fav_$activeId", favorites.toSet())
            .putString("recent_$activeId", recent.joinToString("\n"))
            .apply()
    }

    /** قائمة السيرفرات: رقم 1 = أول سيرفر، رقم 2 = الثاني... */
    fun serverList(): List<String> =
        servers.split(Regex("[\\s,]+")).filter { it.isNotBlank() }
            .map { it.trim().let { u -> if (u.startsWith("http")) u else "http://$u" }.trimEnd('/') }

    fun toggleFav(k: String) {
        if (!favorites.remove(k)) favorites.add(k)
        save()
    }

    fun addRecent(k: String) {
        recent.remove(k)
        recent.add(0, k)
        while (recent.size > 20) recent.removeAt(recent.lastIndex)
        save()
    }

    fun resumeFor(key: String?, url: String): ResumeEntry? =
        if (key == null) null else resume.firstOrNull { it.itemKey == key && it.url == url }

    fun saveResume(e: ResumeEntry) {
        resume.removeAll { it.itemKey == e.itemKey }
        // إذا شاف أكثر من 95% نعتبره منتهياً ونشيله من القائمة
        if (!(e.dur > 0 && e.pos > e.dur * 0.95)) resume.add(0, e)
        while (resume.size > 30) resume.removeAt(resume.lastIndex)
        val a = JSONArray()
        resume.forEach {
            a.put(JSONObject().put("k", it.itemKey).put("u", it.url).put("t", it.title)
                .put("p", it.pos).put("d", it.dur).put("m", it.updated))
        }
        sp.edit().putString("resume_$activeId", a.toString()).apply()
    }
}
