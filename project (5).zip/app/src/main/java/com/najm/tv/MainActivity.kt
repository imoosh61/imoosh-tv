package com.najm.tv

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
val LocalBg = compositionLocalOf { Color(0xFF141414) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.appCtx = applicationContext
        val prefs = Repo.ensurePrefs(this)
        DownloadCenter.init(this)
        DownloadCenter.resumeAll()
        setContent { App(prefs) }
    }
}

// ---------- عناصر مساعدة ----------

@Composable
fun Txt(text: String, size: Int = 16, bold: Boolean = false, color: Color = Color.White, maxLines: Int = Int.MAX_VALUE) {
    Text(
        text, color = color, fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else null,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun Center(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center, content = content)
}

@Composable
fun FocusButton(text: String, selected: Boolean = false, filled: Boolean = false, onClick: () -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val bg = when {
        f -> accent
        filled -> accent.copy(alpha = 0.55f)
        selected -> Color.White.copy(alpha = 0.28f)
        else -> Color.White.copy(alpha = 0.08f)
    }
    Box(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Txt(text, 16, selected || f) }
}

@Composable
fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(color)
            .border(3.dp, if (f) Color.White else if (selected) Color.Gray else Color.Transparent, CircleShape)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
    )
}

@Composable
fun rememberImg(url: String?, w: Int, h: Int): ImageRequest? {
    val ctx = LocalContext.current
    return remember(url, w, h) {
        if (url == null) null else ImageRequest.Builder(ctx).data(url).size(w, h).crossfade(false).build()
    }
}

@Composable
fun Card(item: Item, progress: Float = 0f, onFocus: () -> Unit = {}, onClick: () -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (f) 1.08f else 1f, label = "scale")
    val live = item.type == Type.LIVE
    val gs = LocalGrid.current
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .size((if (live) 190.dp else 130.dp) * gs, (if (live) 110.dp else 190.dp) * gs)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(shape)
            .background(Color(0xFF2A2A2A))
            .then(if (f) Modifier.border(3.dp, accent, shape) else Modifier)
            .onFocusChanged { f = it.isFocused; if (it.isFocused) onFocus() }
            .clickable(onClick = onClick)
    ) {
        val req = rememberImg(item.poster, if (live) 380 else 300, if (live) 220 else 440)
        if (req != null) {
            AsyncImage(
                model = req, contentDescription = null,
                contentScale = if (live) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier.fillMaxSize().padding(if (live) 14.dp else 0.dp)
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                .padding(start = 6.dp, end = 6.dp, top = 6.dp, bottom = if (progress > 0f) 10.dp else 6.dp)
        ) { Txt(item.title, 12, maxLines = 2) }
        if (progress > 0f) {
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp).background(Color.White.copy(alpha = 0.3f))
            ) { Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().background(accent)) }
        }
    }
}

@Composable
fun MoreCard(onClick: () -> Unit) {
    val accent = LocalAccent.current
    val gs = LocalGrid.current
    var f by remember { mutableStateOf(false) }
    Box(
        Modifier
            .size(130.dp * gs, 190.dp * gs)
            .clip(RoundedCornerShape(10.dp))
            .background(if (f) accent else Color(0xFF2A2A2A))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Txt("المزيد ›", 16, true) }
}

fun play(ctx: Context, p: AppPrefs, key: String?, url: String, title: String, live: Boolean = false, fromStart: Boolean = false) {
    if (key != null) p.addRecent(key)
    ctx.startActivity(
        Intent(ctx, PlayerActivity::class.java)
            .putExtra("url", url).putExtra("title", title)
            .putExtra("key", key).putExtra("live", live).putExtra("fromStart", fromStart)
    )
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
}

fun fmtSize(b: Long): String = when {
    b >= (1L shl 30) -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= (1L shl 20) -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%d KB", b / 1024)
}

// ---------- التطبيق ----------

@Composable
fun App(p: AppPrefs) {
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalDensity provides Density(d.density, p.scale),
        LocalAccent provides Palette.accents[p.accent],
        LocalBg provides Palette.bgs[p.bg],
        LocalGrid provides listOf(0.85f, 1f, 1.2f)[p.gridScale.coerceIn(0, 2)]
    ) {
        Box(Modifier.fillMaxSize().background(Palette.bgs[p.bg])) {
            // تسجيل الدخول التلقائي: إذا البيانات محفوظة نفتح مباشرة
            var loggedIn by remember { mutableStateOf(p.mode.isNotEmpty()) }
            if (!loggedIn) {
                LoginScreen(p) { loggedIn = true }
            } else {
                Loader(p, onLogout = { p.mode = ""; p.save(); loggedIn = false })
            }
        }
    }
}

@Composable
fun Loader(p: AppPrefs, onLogout: () -> Unit) {
    var state by remember { mutableStateOf("loading") }
    var msg by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        state = "loading"
        try {
            Repo.load(p)
            state = "ok"
        } catch (e: Exception) {
            msg = e.message ?: e.toString()
            state = "error"
        }
    }
    when (state) {
        "loading" -> Center { Txt("جاري تحميل المحتوى...\nأول مرة قد يستغرق دقيقة، وبعدها يفتح بسرعة", 20) }
        "error" -> Center {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Txt("تعذّر التحميل: $msg", 18, color = Color(0xFFFF6B6B))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FocusButton("إعادة المحاولة", filled = true) { Repo.forceRefresh = true; reload++ }
                    FocusButton("تغيير الحساب") { onLogout() }
                }
            }
        }
        else -> Gate(p, onReload = { Repo.forceRefresh = true; reload++ }, onLogout = onLogout)
    }
}

@Composable
fun LoginScreen(p: AppPrefs, onDone: () -> Unit) {
    var xt by remember { mutableStateOf(p.mode != "m3u") }
    var server by remember { mutableStateOf(p.server) }
    var servers by remember { mutableStateOf(p.servers) }
    var user by remember { mutableStateOf(p.user) }
    var pass by remember { mutableStateOf(p.pass) }
    var m3u by remember { mutableStateOf(p.m3u) }
    var err by remember { mutableStateOf("") }
    var showQr by remember { mutableStateOf(false) }
    var qrUrl by remember { mutableStateOf<String?>(null) }

    fun submit(isXt: Boolean) {
        val hasServer = server.isNotBlank() || servers.isNotBlank()
        val ok = if (isXt) user.isNotBlank() && pass.isNotBlank() && hasServer else m3u.isNotBlank()
        if (!ok) {
            err = if (isXt && user.isNotBlank() && pass.isNotBlank() && !hasServer) {
                "اكتب رقم السيرفر أو رابطه، أو أضف قائمة السيرفرات"
            } else {
                "عبّئ كل الحقول"
            }
            return
        }
        p.mode = if (isXt) "xtream" else "m3u"
        p.server = server; p.servers = servers; p.user = user; p.pass = pass; p.m3u = m3u
        p.resolved = ""
        p.save()
        onDone()
    }

    // خادم الجوال: يشتغل فقط وقت عرض الباركود
    DisposableEffect(showQr) {
        var pl: PhoneLogin? = null
        if (showQr) {
            val h = Handler(Looper.getMainLooper())
            pl = PhoneLogin(mapOf("user" to user, "server" to server, "servers" to servers, "m3u" to m3u)) { d ->
                h.post {
                    user = d["user"] ?: ""
                    pass = d["pass"] ?: ""
                    server = d["server"] ?: ""
                    servers = d["servers"] ?: ""
                    m3u = d["m3u"] ?: ""
                    val useM3u = m3u.isNotBlank() && user.isBlank()
                    xt = !useM3u
                    submit(xt)
                }
            }
            try {
                pl.start()
                qrUrl = pl.url()
            } catch (e: Exception) {
                qrUrl = null
            }
        }
        onDispose { pl?.stop() }
    }

    Center {
        Column(
            Modifier.width(520.dp).verticalScroll(rememberScrollState()).padding(vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Txt("imoosh-tv", 36, true, LocalAccent.current)
            Txt("سجّل دخولك باشتراكك (يُحفظ تلقائياً)", 16, color = Color.LightGray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FocusButton("يوزر وباسورد", selected = xt) { xt = true }
                FocusButton("رابط M3U", selected = !xt) { xt = false }
                FocusButton("📱 الدخول من الجوال", selected = showQr) { showQr = !showQr }
            }
            if (showQr) {
                val bmp = remember(qrUrl) { qrUrl?.let { qrBitmap(it) } }
                if (bmp != null) {
                    Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(220.dp))
                    Txt("امسح الباركود بكاميرا الجوال (لازم الجوال على نفس الواي فاي)", 14, color = Color.LightGray)
                    Txt(qrUrl ?: "", 12, color = Color.Gray)
                } else {
                    Txt("تعذّر تجهيز الباركود، تأكد أن التلفاز متصل بالواي فاي", 14, color = Color(0xFFFF6B6B))
                }
            }
            if (xt) {
                Field("رقم السيرفر أو رابطه (اتركه فارغاً للبحث التلقائي)", server) { server = it }
                Field("اسم المستخدم", user) { user = it }
                Field("كلمة المرور", pass, true) { pass = it }
                Field("قائمة السيرفرات (اختياري، افصل بينها بمسافة)", servers) { servers = it }
            } else {
                Field("رابط قائمة M3U", m3u) { m3u = it }
            }
            if (err.isNotEmpty()) Txt(err, 14, color = Color(0xFFFF6B6B))
            Txt("© imoosh61", 12, color = Color.Gray)
            FocusButton("دخول", filled = true) { submit(xt) }
        }
    }
}

@Composable
fun Field(label: String, value: String, password: Boolean = false, onChange: (String) -> Unit) {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    Column(Modifier.fillMaxWidth()) {
        Txt(label, 13, color = Color.LightGray)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp, textDirection = TextDirection.Ltr),
            cursorBrush = SolidColor(Color.White),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Color(0xFF2A2A2A))
                .border(2.dp, if (f) accent else Color.Transparent, shape)
                .onFocusChanged { f = it.isFocused }
                .padding(12.dp)
        )
    }
}

@Composable
fun Hero(state: State<Item?>) {
    val bg = LocalBg.current
    val target = state.value
    var item by remember { mutableStateOf(target) }
    LaunchedEffect(target) {
        delay(350)
        item = target
    }
    Box(Modifier.fillMaxWidth().height(190.dp)) {
        val req = rememberImg(item?.poster, 640, 360)
        if (req != null) {
            AsyncImage(
                model = req, contentDescription = null, contentScale = ContentScale.Crop,
                alpha = 0.3f, modifier = Modifier.fillMaxSize()
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, bg))))
        val it0 = item
        if (it0 != null) {
            Column(Modifier.align(Alignment.BottomStart).padding(horizontal = 40.dp, vertical = 10.dp)) {
                Txt(it0.title, 30, true, maxLines = 1)
                val meta = listOfNotNull(
                    it0.category,
                    it0.rating.takeIf { r -> r.isNotBlank() && r != "0" }?.let { r -> "★ $r" }
                ).joinToString("  •  ")
                Txt(meta, 14, color = Color.LightGray, maxLines = 1)
                if (it0.plot.isNotBlank()) Txt(it0.plot, 13, color = Color.LightGray, maxLines = 2)
            }
        }
    }
}

/** صف أفقي مع تقسيم لصفحات: يعرض 30 عنصراً ثم زر "المزيد" */
@Composable
fun RowSection(
    title: String,
    list: List<Item>,
    onFocus: (Item) -> Unit = {},
    progress: (Item) -> Float = { 0f },
    open: (Item) -> Unit
) {
    var count by remember(list) { mutableIntStateOf(30) }
    val shown = remember(list, count) { list.take(count) }
    Column(Modifier.padding(bottom = 4.dp)) {
        Box(Modifier.padding(horizontal = 40.dp, vertical = 4.dp)) { Txt(title, 18, true) }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 40.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(shown, key = { it.key }) { it0 -> Card(it0, progress = progress(it0), onFocus = { onFocus(it0) }) { open(it0) } }
            if (list.size > count) item { MoreCard { count += 30 } }
        }
    }
}

// ---------- التنزيلات ----------

fun dlLine(d: DlItem): String {
    val pct = if (d.total > 0) (d.done * 100 / d.total).toInt() else 0
    val sizes = "${fmtSize(d.done)} / ${if (d.total > 0) fmtSize(d.total) else "؟"}"
    return when (d.status) {
        DlStatus.RUNNING -> "$pct% • ${fmtSize(d.speed)}/ث • $sizes"
        DlStatus.WAITING -> (d.note.ifBlank { "في الانتظار..." }) + " • $pct%"
        DlStatus.PAUSED -> "متوقف مؤقتاً • $pct% • $sizes"
        DlStatus.DONE -> "مكتمل • ${fmtSize(maxOf(d.total, d.done))}"
        DlStatus.FAILED -> "فشل: ${d.note} • $pct% (اضغط مواصلة للمحاولة)"
    }
}

@Composable
fun DownloadsScreen(p: AppPrefs) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val list by DownloadCenter.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Txt("التنزيلات", 24, true)
        if (list.isEmpty()) Txt("لا توجد تنزيلات بعد. افتح أي فيلم أو حلقة واضغط تنزيل.", 15, color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { d ->
                val frac = if (d.total > 0) (d.done.toFloat() / d.total).coerceIn(0f, 1f) else 0f
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = 0.06f)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Txt(d.title, 16, true, maxLines = 1)
                    if (d.status != DlStatus.DONE) {
                        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.15f))) {
                            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(accent))
                        }
                    }
                    Txt(dlLine(d), 13, color = Color.LightGray, maxLines = 1)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (d.status) {
                            DlStatus.RUNNING, DlStatus.WAITING -> {
                                FocusButton("⏸ إيقاف مؤقت") { DownloadCenter.pause(d.id) }
                                FocusButton("✖ إلغاء") { DownloadCenter.cancel(d.id) }
                            }
                            DlStatus.PAUSED, DlStatus.FAILED -> {
                                FocusButton("▶ مواصلة", filled = true) { DownloadCenter.resume(ctx, d.id) }
                                FocusButton("✖ إلغاء") { DownloadCenter.cancel(d.id) }
                            }
                            DlStatus.DONE -> {
                                FocusButton("▶ تشغيل", filled = true) {
                                    play(ctx, p, null, Uri.fromFile(File(d.path)).toString(), d.title)
                                }
                                FocusButton("🗑 حذف") { DownloadCenter.cancel(d.id) }
                            }
                        }
                    }
                }
            }
        }
    }
}

