package com.najm.tv

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun Gate(p: AppPrefs, onReload: () -> Unit, onLogout: () -> Unit) {
    val needPick = p.profiles.size > 1 || p.active.pin.isNotEmpty()
    if (needPick && !p.profileChosen) {
        ProfilePicker(p)
    } else {
        key(p.activeId) { Shell(p, onReload, onLogout) }
    }
}

@Composable
fun Shell(p: AppPrefs, onReload: () -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf("main") }
    var detail by remember { mutableStateOf<Item?>(null) }
    var pinTarget by remember { mutableStateOf<Profile?>(null) }
    var pinErr by remember { mutableStateOf("") }
    val exploring = remember { mutableStateListOf(false, false, false) }
    val ls0 = rememberLazyListState()
    val ls1 = rememberLazyListState()
    val ls2 = rememberLazyListState()
    val types = listOf(Type.MOVIE, Type.SERIES, Type.LIVE)
    val d = detail
    val pt = pinTarget

    BackHandler(d != null) { detail = null }
    BackHandler(d == null && pt != null) { pinTarget = null; pinErr = "" }
    BackHandler(d == null && pt == null && screen != "main") { screen = "main" }
    BackHandler(d == null && pt == null && screen == "main" && exploring[tab]) { exploring[tab] = false }

    when {
        d != null -> Detail(p, d)
        pt != null -> Center {
            PinPad(
                title = "رمز ملف ${pt.name}",
                error = pinErr,
                onDone = {
                    if (it == pt.pin) {
                        pinTarget = null
                        pinErr = ""
                        p.switchTo(pt.id)
                    } else {
                        pinErr = "رمز خاطئ"
                    }
                },
                onCancel = { pinTarget = null; pinErr = "" }
            )
        }
        screen != "main" -> {
            val title = when (screen) {
                "search" -> "بحث"
                "menu" -> "الحساب"
                "profiles" -> "الملفات الشخصية"
                "downloads" -> "التنزيلات"
                else -> "الإعدادات"
            }
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FocusButton("‹ رجوع") { screen = if (screen == "profiles" || screen == "downloads" || screen == "settings") "menu" else "main" }
                    Txt(title, 20, true)
                }
                when (screen) {
                    "search" -> SearchScreen(p) { detail = it }
                    "menu" -> MenuScreen(p, onPin = { pinTarget = it }, onNav = { screen = it }, onLogout = onLogout)
                    "profiles" -> ProfilesManager(p)
                    "downloads" -> DownloadsScreen(p)
                    else -> SettingsScreen(p, onReload, onLogout) { screen = "profiles" }
                }
            }
        }
        else -> Column(Modifier.fillMaxSize()) {
            TopBar(p, tab, onTab = { tab = it }, onSearch = { screen = "search" }, onProfile = { screen = "menu" })
            val t = types[tab]
            if (exploring[tab]) {
                CategoryExplorer(p, t, onBack = { exploring[tab] = false }) { detail = it }
            } else {
                Browse(p, t, when (tab) { 0 -> ls0; 1 -> ls1; else -> ls2 }, onExplore = { exploring[tab] = true }) { detail = it }
            }
        }
    }
}

@Composable
fun TopBar(p: AppPrefs, tab: Int, onTab: (Int) -> Unit, onSearch: () -> Unit, onProfile: () -> Unit) {
    val names = listOf("أفلام", "مسلسلات", "بث مباشر")
    // الشريط بترتيب فعلي ثابت: البحث يسار، القوائم وسط، الصورة الشخصية يمين
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 10.dp)) {
            IconBtn("🔍", Modifier.align(Alignment.CenterStart)) { onSearch() }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    names.forEachIndexed { i, n -> FocusButton(n, selected = i == tab) { onTab(i) } }
                }
            }
            AvatarButton(p.active, 40.dp, Modifier.align(Alignment.CenterEnd)) { onProfile() }
        }
    }
}

@Composable
fun Browse(p: AppPrefs, type: Type, state: LazyListState, onExplore: () -> Unit, open: (Item) -> Unit) {
    val ctx = LocalContext.current
    val sec = secOf(type)
    val kids = p.active.kids
    if (sec.items.isEmpty()) {
        Center { Txt("لا يوجد محتوى في هذا القسم", 18, color = Color.Gray) }
        return
    }
    val cats = remember(sec, kids) { sec.cats.filter { !kids || !adultCat(it.first) } }
    val newest = remember(sec, kids) { if (kids) sec.newest.filter { !adultCat(it.category) } else sec.newest }
    val prefix = type.name + ":"
    val cont = p.resume.filter { it.itemKey.startsWith(prefix) }.mapNotNull { Repo.byKey[it.itemKey] }
    val favs = p.favorites.filter { it.startsWith(prefix) }.mapNotNull { Repo.byKey[it] }
    val hero = remember(type) { mutableStateOf<Item?>(newest.firstOrNull() ?: sec.items.firstOrNull()) }
    val progress = { i: Item ->
        p.resume.firstOrNull { it.itemKey == i.key }?.let { if (it.dur > 0) it.pos.toFloat() / it.dur else 0f } ?: 0f
    }
    Column(Modifier.fillMaxSize()) {
        if (p.banner) Hero(hero)
        Row(
            Modifier.padding(horizontal = 40.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FocusButton("▦ كل التصنيفات والتصفية") { onExplore() }
            if (type == Type.LIVE && p.multi.size >= 2) {
                FocusButton("▶ مشاهدة متعددة (${p.multi.size})", filled = true) { startMulti(ctx, p) }
            }
        }
        LazyColumn(Modifier.fillMaxSize(), state = state) {
            if (cont.isNotEmpty()) {
                item(key = "#cont", contentType = "row") {
                    RowSection("متابعة المشاهدة", cont, onFocus = { hero.value = it }, progress = progress) { i ->
                        p.resume.firstOrNull { it.itemKey == i.key }?.let { e -> play(ctx, p, e.itemKey, e.url, e.title) }
                    }
                }
            }
            if (favs.isNotEmpty()) {
                item(key = "#fav", contentType = "row") {
                    RowSection("المفضلة", favs, onFocus = { hero.value = it }, progress = progress, open = open)
                }
            }
            if (type != Type.LIVE) {
                item(key = "#new", contentType = "row") {
                    RowSection("المضافة حديثاً", newest, onFocus = { hero.value = it }, progress = progress, open = open)
                }
            }
            items(cats, key = { it.first }, contentType = { "row" }) { c ->
                RowSection(c.first, c.second, onFocus = { hero.value = it }, progress = progress, open = open)
            }
        }
    }
}

fun startMulti(ctx: android.content.Context, p: AppPrefs) {
    val its = p.multi.mapNotNull { Repo.byKey[it] }
    if (its.size < 2) return
    ctx.startActivity(
        Intent(ctx, MultiViewActivity::class.java)
            .putStringArrayListExtra("urls", ArrayList(its.map { Repo.playUrl(it) }))
            .putStringArrayListExtra("titles", ArrayList(its.map { it.title }))
    )
}

private val ratingOpts = listOf("الكل", "5+", "6+", "7+", "8+")
private val yearOpts = listOf("الكل", "2020 وأحدث", "2010–2019", "2000–2009", "أقدم")
private val sortOpts = listOf("الافتراضي", "الأحدث إضافة", "الاسم", "التقييم", "السنة")
private val groupOpts = listOf("الكل", "رياضة", "أخبار", "أطفال", "أفلام ومسلسلات")
private val groupWords = listOf(
    emptyList(),
    listOf("sport", "bein", "ssc", "رياض", "كأس", "dazn"),
    listOf("news", "أخبار", "اخبار", "jazeera", "الجزيرة", "arabiya", "العربية"),
    listOf("kids", "cartoon", "أطفال", "اطفال", "كرتون", "spacetoon", "toon"),
    listOf("movie", "cinema", "film", "أفلام", "افلام", "سينما", "series", "مسلسل")
)

/** شبكة الفئات: قائمة التصنيفات على الجانب + شبكة العناصر مع تصفية بالتقييم والسنة */
@Composable
fun CategoryExplorer(p: AppPrefs, type: Type, onBack: () -> Unit, open: (Item) -> Unit) {
    val sec = secOf(type)
    val kids = p.active.kids
    val cats = remember(sec, kids) { sec.cats.filter { !kids || !adultCat(it.first) } }
    val isLive = type == Type.LIVE
    var cat by remember { mutableIntStateOf(-1) }
    var rating by remember { mutableIntStateOf(0) }
    var yearB by remember { mutableIntStateOf(0) }
    var sort by remember { mutableIntStateOf(0) }
    var group by remember { mutableIntStateOf(0) }
    var shown by remember { mutableStateOf(emptyList<Item>()) }
    val gs = LocalGrid.current

    LaunchedEffect(cat, rating, yearB, sort, group, cats) {
        shown = withContext(Dispatchers.Default) {
            var l: List<Item> = if (cat < 0 || cat >= cats.size) cats.flatMap { it.second } else cats[cat].second
            if (group > 0) {
                val w = groupWords[group]
                l = l.filter { i -> val c = i.category.lowercase(); val t = i.title.lowercase(); w.any { it in c || it in t } }
            }
            if (rating > 0) {
                val min = 4 + rating
                l = l.filter { (it.rating.toDoubleOrNull() ?: 0.0) >= min }
            }
            if (yearB > 0) {
                l = l.filter {
                    val y = it.year
                    when (yearB) {
                        1 -> y >= 2020
                        2 -> y in 2010..2019
                        3 -> y in 2000..2009
                        else -> y in 1..1999
                    }
                }
            }
            when (sort) {
                1 -> l.sortedByDescending { it.added }
                2 -> l.sortedBy { it.title }
                3 -> l.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }
                4 -> l.sortedByDescending { it.year }
                else -> l
            }
        }
    }

    Row(Modifier.fillMaxSize().padding(horizontal = 40.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        LazyColumn(Modifier.width(230.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item(key = "#back") { FocusButton("‹ رجوع للرئيسية") { onBack() } }
            item(key = "#all") { FocusButton("كل التصنيفات (${cats.sumOf { it.second.size }})", selected = cat < 0) { cat = -1 } }
            items(cats.size, key = { cats[it].first }) { i ->
                FocusButton("${cats[i].first} (${cats[i].second.size})", selected = cat == i) { cat = i }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isLive) {
                    CycleButton("النوع", groupOpts, group) { group = it }
                } else {
                    CycleButton("التقييم", ratingOpts, rating) { rating = it }
                    CycleButton("السنة", yearOpts, yearB) { yearB = it }
                }
                CycleButton("الترتيب", if (isLive) sortOpts.take(3) else sortOpts, sort) { sort = it }
            }
            Txt("${shown.size} نتيجة", 13, color = Color.LightGray)
            LazyVerticalGrid(
                columns = GridCells.Adaptive((if (isLive) 200.dp else 140.dp) * gs),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(shown, key = { it.key }) { i -> Card(i) { open(i) } }
            }
        }
    }
}

@Composable
fun SearchScreen(p: AppPrefs, open: (Item) -> Unit) {
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(emptyList<Item>()) }
    val kids = p.active.kids
    val gs = LocalGrid.current
    LaunchedEffect(q) {
        val s = q.trim()
        if (s.length < 2) {
            res = emptyList()
        } else {
            delay(300)
            res = withContext(Dispatchers.Default) {
                Repo.all.filter { it.title.contains(s, true) && (!kids || !adultCat(it.category)) }.take(90)
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp)) {
        Field("ابحث في الأفلام والمسلسلات والقنوات", q) { q = it }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(160.dp * gs),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(res, key = { it.key }) { i -> Card(i) { open(i) } }
        }
    }
}
