package com.najm.tv

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.PlayerView
import java.util.Locale

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var key: String? = null
    private var url = ""
    private var title = ""
    private var live = false
    private var retries = 0
    private var speedBtn: Button? = null

    private val saver = object : Runnable {
        override fun run() {
            savePos()
            handler.postDelayed(this, 5000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        url = intent.getStringExtra("url") ?: run { finish(); return }
        title = intent.getStringExtra("title") ?: ""
        key = intent.getStringExtra("key")
        live = intent.getBooleanExtra("live", false)
        val fromStart = intent.getBooleanExtra("fromStart", false)
        val prefs = Repo.ensurePrefs(this)

        val root = FrameLayout(this)
        val view = PlayerView(this)
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        val btn = Button(this).apply {
            text = "🔊 الصوت والترجمة"
            setOnClickListener { showTracks() }
        }
        val spd = Button(this).apply {
            text = "⏩ السرعة 1x"
            setOnClickListener { showSpeed() }
        }
        speedBtn = spd
        bar.addView(btn)
        if (!live) bar.addView(spd)
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { setMargins(32, 32, 32, 32) })
        setContentView(root)
        view.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> bar.visibility = v })

        // مخزن مؤقت أكبر + إعادة محاولة أكثر لتقليل التقطيع في IPTV
        val mult = when (prefs.bufferMode) { 0 -> 0.5; 2 -> 2.0; else -> 1.0 }
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(((if (live) 15000 else 30000) * mult).toInt(), ((if (live) 60000 else 120000) * mult).toInt(), 2500, 5000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20000)
            .setReadTimeoutMs(20000)
        val msf = DefaultMediaSourceFactory(http).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(8))
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setLoadControl(lc)
            .setMediaSourceFactory(msf)
            .build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setPreferredAudioLanguage("ar").build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    p.seekToDefaultPosition()
                    p.prepare()
                    return
                }
                if (retries < 5) {
                    retries++
                    Toast.makeText(this@PlayerActivity, "انقطع البث، إعادة المحاولة ($retries/5)", Toast.LENGTH_SHORT).show()
                    handler.postDelayed({ p.prepare() }, 2000L * retries)
                } else {
                    Toast.makeText(this@PlayerActivity, "تعذّر التشغيل: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
            }
        })
        view.player = p
        val saved = if (live || fromStart) null else prefs.resumeFor(key, url)
        if (saved != null) {
            p.setMediaItem(MediaItem.fromUri(url), saved.pos)
            Toast.makeText(this, "المتابعة من آخر نقطة توقف", Toast.LENGTH_SHORT).show()
        } else {
            p.setMediaItem(MediaItem.fromUri(url))
        }
        p.prepare()
        p.playWhenReady = true
        player = p
    }

    private fun savePos() {
        val p = player ?: return
        val k = key ?: return
        if (live) return
        val dur = p.duration
        val pos = p.currentPosition
        if (dur <= 0 || dur == C.TIME_UNSET || pos < 10_000) return
        Repo.ensurePrefs(this).saveResume(ResumeEntry(k, url, title, pos, dur, System.currentTimeMillis()))
    }

    private fun label(f: Format, i: Int): String {
        val lang = f.language?.takeIf { it != "und" }?.let { Locale(it).displayLanguage }
        val parts = listOfNotNull(f.label, lang, f.channelCount.takeIf { it > 0 }?.let { "${it}ch" })
        return parts.distinct().joinToString(" • ").ifEmpty { "مسار ${i + 1}" }
    }

    private fun showSpeed() {
        val p = player ?: return
        val names = arrayOf("0.5x", "1.0x", "1.25x", "1.5x", "2.0x")
        val vals = floatArrayOf(0.5f, 1f, 1.25f, 1.5f, 2f)
        AlertDialog.Builder(this)
            .setTitle("سرعة التشغيل")
            .setItems(names) { _, i ->
                p.setPlaybackSpeed(vals[i])
                speedBtn?.text = "⏩ السرعة " + names[i]
            }
            .show()
    }

    private fun showTracks() {
        if (player == null) return
        AlertDialog.Builder(this)
            .setTitle("الصوت والترجمة")
            .setItems(arrayOf("🔊 مسار الصوت", "💬 الترجمة")) { _, i ->
                pick(if (i == 0) C.TRACK_TYPE_AUDIO else C.TRACK_TYPE_TEXT)
            }
            .show()
    }

    private fun pick(type: Int) {
        val p = player ?: return
        val groups = p.currentTracks.groups.filter { it.type == type && it.isSupported }
        val isText = type == C.TRACK_TYPE_TEXT
        val names = mutableListOf<String>()
        if (isText) names.add("إيقاف الترجمة")
        groups.forEachIndexed { i, g -> names.add(label(g.getTrackFormat(0), i)) }
        if (groups.isEmpty()) {
            Toast.makeText(this, if (isText) "لا توجد ترجمة في هذا المحتوى" else "لا توجد مسارات صوت إضافية", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(if (isText) "الترجمة" else "مسار الصوت")
            .setItems(names.toTypedArray()) { _, which ->
                val b = p.trackSelectionParameters.buildUpon()
                if (isText && which == 0) {
                    b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                } else {
                    val g = groups[which - (if (isText) 1 else 0)]
                    b.setTrackTypeDisabled(type, false)
                    b.setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, (0 until g.length).toList()))
                }
                p.trackSelectionParameters = b.build()
            }
            .show()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN &&
            (event.keyCode == KeyEvent.KEYCODE_MENU || event.keyCode == KeyEvent.KEYCODE_CAPTIONS)
        ) {
            showTracks()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        handler.postDelayed(saver, 5000)
    }

    override fun onStop() {
        handler.removeCallbacks(saver)
        savePos()
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
