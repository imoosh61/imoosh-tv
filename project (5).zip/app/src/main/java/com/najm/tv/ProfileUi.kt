package com.najm.tv

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** شاشة "من يشاهد؟" عند فتح التطبيق */
@Composable
fun ProfilePicker(p: AppPrefs) {
    var target by remember { mutableStateOf<Profile?>(null) }
    var err by remember { mutableStateOf("") }
    val t = target
    Center {
        if (t != null) {
            PinPad(
                title = "رمز ملف ${t.name}",
                error = err,
                onDone = {
                    if (it == t.pin) {
                        p.switchTo(t.id)
                        p.profileChosen = true
                    } else {
                        err = "رمز خاطئ"
                    }
                },
                onCancel = { target = null; err = "" }
            )
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(24.dp)) {
                Txt("من يشاهد؟", 32, true)
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                    p.profiles.forEach { pr ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            AvatarButton(pr, 96.dp) {
                                if (pr.pin.isEmpty()) {
                                    p.switchTo(pr.id)
                                    p.profileChosen = true
                                } else {
                                    target = pr
                                }
                            }
                            Txt(pr.name + (if (pr.pin.isNotEmpty()) " 🔒" else "") + (if (pr.kids) " 👶" else ""), 16)
                        }
                    }
                }
            }
        }
    }
}

/** قائمة الصورة الشخصية: تبديل الملف + اختصارات */
@Composable
fun MenuScreen(p: AppPrefs, onPin: (Profile) -> Unit, onNav: (String) -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Txt("تبديل الملف الشخصي", 20, true)
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            p.profiles.forEach { pr ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    AvatarButton(pr, 72.dp, selected = pr.id == p.activeId) {
                        when {
                            pr.id == p.activeId -> onNav("main")
                            pr.pin.isNotEmpty() -> onPin(pr)
                            else -> p.switchTo(pr.id)
                        }
                    }
                    Txt(pr.name + (if (pr.pin.isNotEmpty()) " 🔒" else ""), 14)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FocusButton("👥 إدارة الملفات") { onNav("profiles") }
            FocusButton("⬇ التنزيلات") { onNav("downloads") }
            FocusButton("⚙ الإعدادات والاشتراك") { onNav("settings") }
        }
        FocusButton("تسجيل الخروج من الاشتراك") { onLogout() }
    }
}

@Composable
fun ProfilesManager(p: AppPrefs) {
    var editing by remember { mutableStateOf<Profile?>(null) }
    var creating by remember { mutableStateOf(false) }
    val e = editing
    if (creating || e != null) {
        ProfileForm(
            initial = e,
            onSave = { pr ->
                if (e == null) p.addProfile(pr.name, pr.avatar, pr.pin, pr.kids) else p.updateProfile(pr)
                editing = null
                creating = false
            },
            onCancel = { editing = null; creating = false }
        )
    } else {
        Column(Modifier.fillMaxSize().padding(horizontal = 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Txt("الملفات الشخصية", 24, true)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(p.profiles.toList(), key = { it.id }) { pr ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Avatar(pr, 48.dp)
                        Column(Modifier.weight(1f)) {
                            Txt(pr.name, 18, true)
                            Txt(listOfNotNull(if (pr.pin.isNotEmpty()) "🔒 محمي برمز" else null, if (pr.kids) "👶 أطفال" else null).joinToString("  "), 13, color = Color.LightGray)
                        }
                        FocusButton("✎ تعديل") { editing = pr }
                        if (p.profiles.size > 1) FocusButton("🗑 حذف") { p.deleteProfile(pr.id) }
                    }
                }
                item { FocusButton("＋ إضافة ملف جديد", filled = true) { creating = true } }
            }
        }
    }
}

@Composable
fun ProfileForm(initial: Profile?, onSave: (Profile) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var avatar by remember { mutableIntStateOf(initial?.avatar ?: 0) }
    var kids by remember { mutableStateOf(initial?.kids ?: false) }
    var pin by remember { mutableStateOf(initial?.pin ?: "") }
    var settingPin by remember { mutableStateOf(false) }
    if (settingPin) {
        Center { PinPad("اكتب رمزاً من 4 أرقام", onDone = { pin = it; settingPin = false }, onCancel = { settingPin = false }) }
    } else {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 40.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Txt(if (initial == null) "ملف جديد" else "تعديل الملف", 24, true)
            Field("اسم الملف", name) { name = it }
            Txt("الصورة", 16, color = Color.LightGray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AVATARS.indices.forEach { i ->
                    AvatarButton(Profile("x", "", i), 52.dp, selected = i == avatar) { avatar = i }
                }
            }
            FocusButton(if (kids) "👶 ملف أطفال: مفعّل" else "👶 ملف أطفال: معطّل") { kids = !kids }
            Txt("ملف الأطفال يخفي الفئات غير المناسبة من القوائم والبحث", 13, color = Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (pin.isEmpty()) {
                    FocusButton("🔒 تفعيل رمز PIN") { settingPin = true }
                } else {
                    FocusButton("🔒 تغيير الرمز") { settingPin = true }
                    FocusButton("🔓 إزالة الرمز") { pin = "" }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FocusButton("حفظ", filled = true) {
                    onSave(Profile(initial?.id ?: "", name.trim().ifBlank { "ملف" }, avatar, pin, kids))
                }
                FocusButton("إلغاء") { onCancel() }
            }
        }
    }
}
