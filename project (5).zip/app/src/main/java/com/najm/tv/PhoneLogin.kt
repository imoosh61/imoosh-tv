package com.najm.tv

import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import kotlin.concurrent.thread

fun qrBitmap(text: String, size: Int = 480): ImageBitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val px = IntArray(size * size) { i ->
        if (m.get(i % size, i / size)) android.graphics.Color.BLACK else android.graphics.Color.WHITE
    }
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    bmp.setPixels(px, 0, size, 0, 0, size, size)
    return bmp.asImageBitmap()
}

fun localIp(): String? = try {
    NetworkInterface.getNetworkInterfaces().toList()
        .flatMap { it.inetAddresses.toList() }
        .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }
        ?.hostAddress
} catch (e: Exception) {
    null
}

/** خادم صغير على التلفاز: الجوال يفتح الرابط (من QR) ويعبّي البيانات ويرسلها للتلفاز */
class PhoneLogin(
    private val current: Map<String, String>,
    private val onData: (Map<String, String>) -> Unit
) {
    private val token = (100000..999999).random().toString()
    private var ss: ServerSocket? = null

    fun start() {
        val s = ServerSocket(0)
        ss = s
        thread(isDaemon = true) {
            while (!s.isClosed) {
                try {
                    s.accept().use { handle(it) }
                } catch (_: Exception) { }
            }
        }
    }

    fun stop() {
        try { ss?.close() } catch (_: Exception) { }
    }

    fun url(): String? {
        val ip = localIp() ?: return null
        val port = ss?.localPort ?: return null
        return "http://$ip:$port/$token"
    }

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = i.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) break
            if (c != '\r'.code) sb.append(c.toChar())
        }
        return sb.toString()
    }

    private fun handle(sock: Socket) {
        sock.soTimeout = 5000
        val inp = sock.getInputStream().buffered()
        val first = readLine(inp) ?: return
        val parts = first.split(" ")
        if (parts.size < 2) return
        val method = parts[0]
        val path = parts[1].substringBefore('?')
        var len = 0
        while (true) {
            val l = readLine(inp) ?: break
            if (l.isEmpty()) break
            if (l.startsWith("content-length:", true)) len = l.substring(15).trim().toIntOrNull() ?: 0
        }
        val out = sock.getOutputStream()
        if (path != "/$token") {
            respond(out, 404, "Not found")
            return
        }
        if (method == "POST") {
            val body = ByteArray(len.coerceIn(0, 20000))
            var off = 0
            while (off < body.size) {
                val n = inp.read(body, off, body.size - off)
                if (n < 0) break
                off += n
            }
            val data = String(body, 0, off, Charsets.UTF_8).split("&").mapNotNull { kv ->
                val i = kv.indexOf('=')
                if (i < 0) null else URLDecoder.decode(kv.substring(0, i), "UTF-8") to URLDecoder.decode(kv.substring(i + 1), "UTF-8")
            }.toMap()
            respond(out, 200, page("<h2>تم الإرسال ✓</h2><p>ارجع للتلفاز، يتم تسجيل دخولك الآن.</p>"))
            onData(data)
        } else {
            respond(out, 200, page(form()))
        }
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun form(): String {
        val servers = (current["servers"] ?: "").split(Regex("[\\s,]+")).filter { it.isNotBlank() }.joinToString("\n")
        return """
            <h2>imoosh-tv</h2>
            <form method="post">
            اسم المستخدم
            <input name="user" value="${esc(current["user"] ?: "")}" autocapitalize="none" autocorrect="off">
            كلمة المرور
            <input name="pass" autocapitalize="none" autocorrect="off">
            رقم السيرفر أو رابطه (اتركه فارغاً للبحث التلقائي)
            <input name="server" value="${esc(current["server"] ?: "")}" autocapitalize="none" autocorrect="off">
            قائمة السيرفرات (سيرفر في كل سطر، الأول رقمه 1)
            <textarea name="servers" rows="4" autocapitalize="none" autocorrect="off">${esc(servers)}</textarea>
            أو رابط M3U بدل ما فوق
            <input name="m3u" value="${esc(current["m3u"] ?: "")}" autocapitalize="none" autocorrect="off">
            <button type="submit">إرسال إلى التلفاز</button>
            </form>
        """.trimIndent()
    }

    private fun page(body: String) = """
        <!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <style>
        body{font-family:sans-serif;background:#141414;color:#fff;padding:20px;font-size:18px}
        input,textarea{width:100%;padding:12px;margin:6px 0 16px;border-radius:8px;border:0;font-size:18px;box-sizing:border-box;direction:ltr}
        button{background:#e50914;color:#fff;border:0;padding:14px;width:100%;font-size:20px;border-radius:8px}
        </style></head><body>$body</body></html>
    """.trimIndent()

    private fun respond(out: OutputStream, code: Int, html: String) {
        val b = html.toByteArray(Charsets.UTF_8)
        val status = if (code == 200) "OK" else "Not Found"
        out.write(
            ("HTTP/1.1 $code $status\r\nContent-Type: text/html; charset=utf-8\r\n" +
                "Content-Length: ${b.size}\r\nConnection: close\r\n\r\n").toByteArray()
        )
        out.write(b)
        out.flush()
    }
}
